<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Desplegar el dato desde el Formulario
// -----------------------------------------------

print_r($_POST);
echo "<br><br>";

// Verifico primero que los datos existan
if (isset($_POST['nmDato1']) && isset($_POST['nmDato2']))
{
    // Obtengo los datos
	$dato1 = $_POST['nmDato1'];
	$dato2 = $_POST['nmDato2'];

  
    // Verificando cual es el dato mayor
    if ($dato1 > $dato2)	
    {
       echo "a) El Dato1: $dato1 es mayor que el Dato2: $dato2<br>";
    }    
    elseif ($dato2 > $dato1)	
    {
       echo "b) El Dato2: $dato2 es mayor que el Dato1: $dato1<br>";
    }
    else
    {
       echo "c)El Dato1: $dato1 es igual que el Dato2: $dato2<br>";
    }
    
}
else
{
	echo "Faltan datos en el Envio<br>";
}

echo "Programa Finalizado";
?>



