<?php

print_r($_POST);
echo "<br><br>";

// Verifico primero que los datos existan
if (isset($_POST['nmDato1']) && 
	isset($_POST['nmDato2']))
{
	// Obtengo los datos
	$dato1 = $_POST['nmDato1'];
	$dato2 = $_POST['nmDato2'];

	// Variable para suma
	$suma = $dato1 + $dato2;
 
    // Desplegamos la suma
	echo "La Suma de $dato1 + $dato2 es:$suma";
}
else
{
	echo "Faltan datos en el Envio<br>";
}

?>



