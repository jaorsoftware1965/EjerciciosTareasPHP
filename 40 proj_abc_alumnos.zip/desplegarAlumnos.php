<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alumnos</title>
    <style>
        table, td, th 
        {  
           border: 1px solid #ddd;
           text-align: left;
        }
        th {background-color: limegreen;}
          
        table {
          border-collapse: collapse;
          width: 100%;
        }
        
        th, td {
          padding: 8px;
          text-align: left;
          border-bottom: 1px solid #ddd;
        }
        
        tr:hover {background-color: lightgreen;}
    </style>
</head>
<body>      
    <h2>Alumnos Registrados</h2>    
    <table>
        <tr>
          <th>Id</th>  
          <th>Nombre</th>
          <th>Apellido</th>
          <th>Carrera</th>
        </tr>
        <?php
          // Mensaje de carga
          //echo "Cargando configuracion ...<br>";

          // Se incluye el archivo de configuracion
          require ('php/config.php');

          // Mensaje de carga
          //echo "Intentando conexion ...<br>";

          // Se realiza la conexión
          $conexion = mysqli_connect(cServidor, cUsuario, cPass, cBd);

          // Conexion lograda
          //echo "Conexion lograda ...<br>";

          // Consulta
          //echo "Ejecutando Consulta ...".$sql."<br>";

          // Prepara consulta
          $consulta = "SELECT * FROM alumnos";

          // Ejecuta la consulta
          $resultados=mysqli_query($conexion,$consulta);
          
          // Obtiene los resultados
          //$datos_nm = mysqli_fetch_assoc($resultados);

          while($registro = mysqli_fetch_assoc($resultados))
          {
        ?>  
            <tr>
              <td><?php echo $registro['id'];?></td>
              <td><?php echo $registro['nombre'];?></td>
              <td><?php echo $registro['apellido'] ;?></td>
              <td><?php echo $registro['carrera'];?></td>
            </tr>                    
        <?php
          }
          // Libera resultados
          mysqli_free_result($consulta_nm);

          // Cierra la Conexion
          mysqli_close($conexion);
        ?>                         
    </table>
    <a href="principal.html"><p>Regresar</p></a>
</body>
</html>
        