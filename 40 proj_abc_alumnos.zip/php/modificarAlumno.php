<?php

// Mensaje de carga
// echo "Cargando configuracion ...<br>";

// Se incluye el archivo de configuracion
require ('config.php');

// Mensaje de carga
// echo "Intentando conexion ...<br>";

// Se realiza la conexión
$conexion = mysqli_connect(cServidor, cUsuario, cPass, cBd);

// Mensaje de carga
// echo "Verificando conexion ...<br>";
if (!$conexion) 
{
    // mensaje de que ha fallado
    echo "No se ha logrado la conexion ...<br>";
}
else
{
    // Mensaje de conexion lograda
    // echo 'Se ha logrado la conexion con exito';	    

    // Verifica si llegaron los datos
    if (isset($_POST["modificarId"]) && 
        isset($_POST["modificarNombre"]) && 
        isset($_POST["modificarApellido"]) && 
        isset($_POST["modificarCarrera"])) 
    {    
        // Prepara la Modificación
        $consulta  = " UPDATE alumnos SET ";
        $consulta .= " nombre   = '".$_POST['modificarNombre']  ."',";
        $consulta .= " apellido = '".$_POST['modificarApellido']."',";
        $consulta .= " carrera  = '".$_POST['modificarCarrera'] ."' ";

        // Agrega la condición
        $consulta .= " WHERE id = ".$_POST['modificarId'];

        // Desplegando consulta
        // echo $consulta."<br>";

        // Intenta la insercion
        if (mysqli_query($conexion, $consulta)) 
        {
            // Obtiene el numero de registros actualizados
            $registrosActualizados = mysqli_affected_rows($conexion);

            // Verifica que sea mayor que 0
            if ($registrosActualizados>0)
            {
                // Redirecciona a Exito
                header("Location: ../exitoAlumnos.html");
            }
            else
            {
                // Redirecciona a Error
                header("Location: ../warningAlumnos.html");
            }                        
        } 
        else 
        {
            //echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            // Redirecciona a Error
            header("Location: ../errorAlumnos.html");
        }        
    }
    else
    {
        // Mensaje de Error
        echo "Error en Parámetros<br>";
    }

    // Cierra la Conexion
    mysqli_close($conexion);
}
?>