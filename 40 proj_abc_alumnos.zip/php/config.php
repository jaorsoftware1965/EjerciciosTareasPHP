<?php

// Defino las Variables de Conexión
define("cServidor", "localhost");
define("cUsuario", "root");
define("cPass","admin");
define("cBd","bdTest");

?>
