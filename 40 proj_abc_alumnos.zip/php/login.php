<?php

// Mensaje de carga
// echo "Cargando configuracion ...<br>";

// Se incluye el archivo de configuracion
require ('config.php');

// Mensaje de carga
// echo "Intentando conexion ...<br>";

// Se realiza la conexión
$conexion = mysqli_connect(cServidor, cUsuario, cPass, cBd);

// Mensaje de carga
//echo "Verificando conexion ...<br>";
if (!$conexion) 
{
    // mensaje de que ha fallado
    echo "No se ha logrado la conexion ...<br>";
}
else
{
    // Mensaje de conexion lograda
    //echo 'Se ha logrado la conexion con exito';	

    // Prepara la Consulta
    $consulta  = "Select * FROM usuarios";

    // Verifica si hay linea
    if (isset($_POST["loginNombre"]) && isset($_POST["loginClave"])) 
    {    
        // Agrega la Linea como Condición
        $consulta.=" WHERE  nombre ='".$_POST['loginNombre']."'";
        $consulta.=" AND    clave  ='".$_POST['loginClave']."'";   

        // Desplegando consulta
        //echo $consulta."<br>";

        // Ejecuta el Query para obtener los Registros
        $registro = mysqli_query($conexion, $consulta);

        // Verifica si hubo acceso
        if (mysqli_fetch_array($registro))
        {
            // Redirecciona a Error
            header("Location: ../principal.html");
        }
        else
        {
            // Redirecciona a Error
            header("Location: ../errorLogin.html");
        }
    }
    else
    {
        // Mensaje de Error
        echo "Error en Parámetros de Login<br>";
    }

    // Cierra la Conexion
    mysqli_close($conexion);
}
?>