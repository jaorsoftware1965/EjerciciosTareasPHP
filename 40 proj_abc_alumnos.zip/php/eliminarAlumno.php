<?php

// Mensaje de carga
//echo "Cargando configuracion ...<br>";

// Se incluye el archivo de configuracion
require ('config.php');

// Mensaje de carga
//echo "Intentando conexion ...<br>";

// Se realiza la conexión
$conexion = mysqli_connect(cServidor, cUsuario, cPass, cBd);

// Mensaje de carga
//echo "Verificando conexion ...<br>";
if (!$conexion) 
{
    // mensaje de que ha fallado
    echo "No se ha logrado la conexion ...<br>";
}
else
{
    // Mensaje de conexion lograda
    //echo 'Se ha logrado la conexion con exito';	    

    // Verifica si llegaron los datos
    if (isset($_POST["eliminarId"])) 
    {    
        // Prepara la Modificación
        $consulta  = " DELETE FROM alumnos WHERE id = ".$_POST['eliminarId'];

        // Desplegando consulta
        //echo $consulta."<br>";

        // Intenta la insercion
        if (mysqli_query($conexion, $consulta)) 
        {
            // Obtiene el numero de registros eliminados
            $registrosEliminados = mysqli_affected_rows($conexion);

            // Verifica que sea mayor que 0
            if ($registrosEliminados>0)
            {
                // Redirecciona a Exito
                header("Location: ../exitoAlumnos.html");
            }
            else
            {
                // Redirecciona a Error
                header("Location: ../warningAlumnos.html");
            }                        
        } 
        else 
        {
            //echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            // Redirecciona a Error
            header("Location: ../errorAlumnos.html");
        }        
    }
    else
    {
        // Mensaje de Error
        echo "Error en Parámetros<br>";
    }

    // Cierra la Conexion
    mysqli_close($conexion);
}
?>