<?php

// Imprime el POST
echo "POST<br>";
print_r($_POST);
echo "<br><br>";

// Verifica que haya llegado
if (isset($_POST["comando"]))
{	
	  // Obtiene el comando
	  $comando = $_POST["comando"];
    
    // Prepara el Documento html para que procese el texto como llega
    //echo '<pre>';

    // Muestra el resultado completo del comando "ls", y devuelve la
    // ultima linea de la salida en $ultima_linea. Almacena el valor de
    // retorno del comando en $retval.
    //$ultima_linea = system($comando, $retval);
    system($comando, $retval);
    //exec($comando,$lineas,$retval);
    //$salida = shell_exec($comando);
    //echo "<pre>$salida</pre>";
    //$retval=0;

    // Imprimir informacion adicional
    //echo '</pre>';
    if ($retval!=0)
      echo "El Sistema Operativo no reconoció el Archivo<br>";
    else
    {
      echo "Archivo ejecutado con Éxito<br>";
      //print_r($lineas);
    }
      
        
}
else
{
	echo "No llegaron los datos<br>";
}

// Mensaje
echo "<br>Programa Terminado<br>";

?>