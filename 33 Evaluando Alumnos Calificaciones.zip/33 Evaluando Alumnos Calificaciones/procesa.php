<?php

// Imprime el POST
echo "POST<br>";
print_r($_POST);
echo "<br><br>";

// Verifica que haya llegado
if (isset($_POST["datos"]))
{	
	  // Separa los datos
	  $datos = explode(";",$_POST["datos"]);
    echo "arreglo datos:<br>";
    print_r($datos);
    echo "<br><br>";

    // Contadores
    $hombres   = 0;
    $mujeres   = 0;
    $sobrepeso = 0;
    $errores   = 0;
    $mujeresConSobrepeso   = 0;
    $hombresAlturaMayor170 = 0;
    $mujeresAlturaMayor150 = 0;
    $errorEnEstatura = 0;
    $errorEnPeso     = 0;
    $errorEnGenero   = 0;


    // Ciclo
    foreach ($datos as $valor) 
    {
        // Obtiene el dato del Alumn
        $persona = explode(",", $valor);
              
        // Verifica que sean 4 datos
        if (count($persona) == 4)
        {
           // Inicializa Diferencia
           $diferencia = 0;

           // Verifica estatura y peso
           if (is_numeric($persona[2]) && is_numeric($persona[3]))
           {                
                // Verifica el sobrepeso
                $diferencia = $persona[2] * 100 - $persona[3]; 

                // Verifica si hay sobrepeso
                if ($diferencia < 100)
                {         
                  $sobrepeso++;
                }           
           }
           if (!is_numeric($persona[2])) 
           {
               $errorEnEstatura++;
           }

           if (!is_numeric($persona[3])) 
           {
               $errorEnPeso++;
           }
           
           // Cuenta generos
           if ($persona[1]=="H")
           {
              // Incrementa los hombres
              $hombres++;

              // Verifica altura
              if ($persona[2]>=1.70)
              {
                 $hombresAlturaMayor170++;
              }
           }
           elseif ($persona[1]=="M")
           {
              // Incrementa las mujeres
              $mujeres++;

              if ($persona[2]>=1.50)
              {
                 $mujeresAlturaMayor150++;
              }
           }
           else
           {
               // Error en Genero
               $errorEnGenero++;
           }
        
           // Verifica mujeres con sobrepeso
           if ($persona[1]=="M" && 
              ($diferencia<100 && $diferencia >0))
           {
              $mujeresConSobrepeso++;
           }
        }
        else
        {
            // Incrementa los errores
            $errores++;
        }
    }

    // MEnsajes
    echo "Las Personas Recibidos:".count($datos)."<br>";
    echo "Las Personas Mujeres:$mujeres<br>";
    echo "Las Personas Hombres:$hombres<br>";
    echo "Las Personas con SobrePeso:$sobrepeso<br>";
    echo "Los Datos Erroneos:$errores<br>";
    echo "Mujeres con SobrePeso:$mujeresConSobrepeso<br>";
    echo "Hombres Altura Mayor 1.70:$hombresAlturaMayor170<br>";
    echo "Mujeres Altura Mayor 1.50:$mujeresAlturaMayor150<br>";
    echo "Errores en Genero:$errorEnGenero<br>";
    echo "Errores en Peso:$errorEnPeso<br>";
    echo "Errores en Estatura:$errorEnEstatura<br>";
	
}
else
{
	echo "No llegaron los datos<br>";
}

// Mensaje
echo "<br>Programa Terminado<br>";

?>