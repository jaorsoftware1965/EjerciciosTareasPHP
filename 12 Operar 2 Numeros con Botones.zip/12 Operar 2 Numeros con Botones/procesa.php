<?php

print_r($_POST);
echo "<br><br>";

// Verifico primero que los datos existan
if (isset($_POST['nmDato1']) && 
	isset($_POST['nmDato2']))
{
	// Obtengo los datos
	$dato1 = $_POST['nmDato1'];
	$dato2 = $_POST['nmDato2'];


	// Vºerifica que operación realizar
	if (isset($_POST['sumar']))
	{
		// Ejecuta Suma
	    $resultado = $dato1 + $dato2;

	    // Obtiene el operador
	    $op = $_POST['sumar'];

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";
	}
	elseif (isset($_POST['restar']))
	{
	    // Ejecuta Resta
	    $resultado = $dato1 - $dato2;

	    // Obtiene el operador
	    $op = $_POST['restar'];

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";	
	}
	elseif (isset($_POST['multiplicar']))
	{
	    // Ejecuta Multiplicación
	    $resultado = $dato1 * $dato2;

		// Obtiene el operador
	    $op = $_POST['multiplicar'];	    

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";		
	}
	else
	{
		// Ejecuta División
	    $resultado = $dato1 / $dato2;

	    // Obtiene el operador
	    $op = $_POST['dividir'];	    

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";	

	}
}
else
{
	echo "Faltan datos en el Envio<br>";
}

echo "<br>Programa Terminado";

?>



