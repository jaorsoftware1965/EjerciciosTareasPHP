<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        table{
            border:1px solid black;
        }
        td{
            border:1px solid black;
            size: 4rem;
        }
    </style>
</head>

<body>

<?php


// -------------------------------------------
// bingo.php
// archivo de clases
// -------------------------------------------

// --------------------------------------------------------------------------------
// Definimos la Clase Linea
// --------------------------------------------------------------------------------
class Linea
{
        // Atributos
        private $numeros;
        private $marcados;
        
        // Constructor
        // Aca tengo la duda de si debe recibir los 5 numeros por separado
        // o tambien recibe un arreglo; los puse separados
        function __construct($num1,$num2,$num3,$num4,$num5)
        {
            // Mensaje de Inicializacion
            echo "Ejecutando el Constructor de Linea...<br>";

            // Coloca los numeros usando el settter
            $this->setNumeros($num1,$num2,$num3,$num4,$num5);

            // Coloca los valores de false iniciales
            $this->setMarcados(FALSE,FALSE,FALSE,FALSE,FALSE);
            
            // Mensaje de Finalizacion
            echo "Constructor de Linea Finalizado ...<br>";
        }

        // Método para marcar
        function marcar($numero)
        {
            // Verifica que el $numero exista en $numeros
            for ($x = 0; $x < 5; $x++) 
            {
                // Verifica si corresponde al numero
                if ($this->numeros[$x]==$numero)
                {
                    // Coloca su correspondiente en true en $marcados
                    $this->marcados[$x]==TRUE;

                    // Sale del Ciclo
                    break;
                }
            }                        
        }

        // Método completo
        function completo()
        {
            // Variable para el resultado
            $resultado = TRUE;
            
            // Ciclo para verificar si todos los marcados son True
            for ($x = 0; $x < 5; $x++) 
            {
                // Verifica si corresponde al numero
                if (!$this->marcados[$x])
                {            
                    // Coloca en FALSE el resultado
                    $resultado = FALSE;

                    // Sale del Ciclo
                    break;
                }
            }
            
            // Devuelve el resultado
            return $resultado;
        }

        // Metodo para desplegar(Este no sirve, lo puse para depurar)
        function desplegar()
        {
            // Mensaje
            echo "Desplegando la linea ...<br>";
            print_r($this->numeros);
            echo "<br><br>";
        }

        // Metodo para desplegarMarcados(Este no sirve, lo puse para depurar)
        function desplegarMarcados()
        {
            // Mensaje
            echo "Desplegando marcados ...<br>";
            print_r($this->marcados);
            echo "<br><br>";
        }

        // Método getter de numeros
        function getNumeros()
        {
            // Retorna los numeros
            $this->numeros;
        }

        // Método getter de marcados
        function getMarcados()
        {
            // Retorna los numeros
            $this->marcados;
        }

        // Método setter de numeros
        function setNumeros($n1,$n2,$n3,$n4,$n5)
        {
            // Coloca los numeros
            $this->numeros[0] = $n1;
            $this->numeros[1] = $n2;
            $this->numeros[2] = $n3;
            $this->numeros[3] = $n4;
            $this->numeros[4] = $n5;
        }

        // Método setter de marcados
        function setMarcados($v1,$v2,$v3,$v4,$v5)
        {
            // Coloca los valores
            $this->marcados[0] = $v1;
            $this->marcados[1] = $v2;
            $this->marcados[2] = $v3;
            $this->marcados[3] = $v4;
            $this->marcados[4] = $v5;
        }        
}

// --------------------------------------------------------------------------------
// Definimos la Clase Carton
// --------------------------------------------------------------------------------
class Carton
{
    // Atributos
    private $lineas;

    // Constructor
    function __construct($linea1,$linea2,$linea3)
    {
        // Mensaje de Inicializacion
        echo "Ejecutando el Constructor de Carton ...<br>";

        
        // Mensaje de Finalizacion
        echo "Constructor de Carton Finalizado ...<br>";        
    }

    // Método para marcar
    function marcar($numero)
    {
        // Contador de lineas completas
        $lineasCompletas = 0;

        // Pasa el numero a las 3 lineas
        for ($x = 1; $x <= 3; $x++) 
        {
            // Pasa el Numero a las 3 lineas
            $lineas[$x]->marcar($numero);         

            // Verifica si está completa
            if ($lineas[$x]->completo())
            {
                // Incrementa el Contador
                $lineasCompletas++;
            }
        }                        
        
        // Retorna las lineas completas
        return $lineasCompletas;
    }

    // Método bingo
    function bingo($numero)
    {
        // Variable para el resultado
        $resultado = TRUE;

        // Pasa el numero a las 3 lineas
        for ($x = 1; $x <= 3; $x++) 
        {
            // Verifica si NO está completa
            if (!$lineas[$x]->completo())
            {
                // Cambia el resultado a false
                $resultado = FALSE;

                // Sale del Ciclo
                break;
            }
        }
        
        // Retorna el resultado
        return $resultado;
    }

    // Método getter de lineas
    function getLineas()
    {
        // Retorna las lineas
        return $this->lineas;
    }

    // Método setter de lineas
    function setLineas($linea1,$linea2,$linea3)
    {
        // Coloca las lineas
        $this->lineas[0] = new Linea($linea1[0],$linea1[1],$linea1[2],$linea1[3],$linea1[4]);
        $this->lineas[1] = new Linea($linea2[0],$linea2[1],$linea2[2],$linea2[3],$linea2[4]);
        $this->lineas[2] = new Linea($linea3[0],$linea3[1],$linea3[2],$linea3[3],$linea3[4]);
    }
}

// --------------------------------------------------------------------------------
// Definimos la Clase Juego
// --------------------------------------------------------------------------------
class Juego
{
    // Crea un arreglo de 3 cartones
    private $cartones;

    // Bolas que ya han salida
    private $bolas;

    // Linea Cantada
    private $lineaCantada;

    // Constructor
    function __construct($numeroCartones)
    {
        // Verifica que sea un numero entre 3-5;
        if ($numeroCartones>=3 and $numeroCartones<=5)
        {            
            echo "Creando un Juego con ".$numeroCartones." Cartones ...<br>";    
            
            // Ciclo para generar los cartones
            for ($i=1; $i<=$numeroCartones;$i++)
            {
                // Ejecuta el carton
                echo "Carton :".$i."<br>";                
                $columnas = $this->generarCarton();

                // Despliega la fila 0
                print_r($columnas[0]);
                echo "<br>";                
                print_r($columnas[1]);
                echo "<br>";                
                print_r($columnas[2]);
                echo "<br>";                
                print_r($columnas[3]);
                echo "<br>";                
                print_r($columnas[4]);
                echo "<br>";                
                print_r($columnas[5]);
                echo "<br>";       
                print_r($columnas[6]);
                echo "<br>";                
                print_r($columnas[7]);
                echo "<br>";                
                print_r($columnas[8]);
                echo "<br>";                
                
                // Mensaje
                echo "Generando las 3 lineas ...<br>";
                
                // Inicializando las linea1
                $linea1=[];
                
                // Creando las lineas
                for ($j=0; $j<9; $j++)
                {
                    // Verifica que no sea 0
                    if ($columnas[$j][2]>0)
                    {
                        // Lo Agrega a la Linea
                        array_push($linea1,$columnas[$j][2]);
                    }
                }

                // Desplegando la linea
                print_r($linea1);
                echo "<br>";

                // Inicializando las linea2
                $linea2=[];
                
                // Creando las lineas
                for ($j=0; $j<9; $j++)
                {
                    // Verifica que no sea 0
                    if ($columnas[$j][1]>0)
                    {
                        // Lo Agrega a la Linea
                        array_push($linea2,$columnas[$j][1]);
                    }
                }

                // Desplegando la linea
                print_r($linea2);
                echo "<br>";

                // Inicializando las linea 3
                $linea3=[];
                
                // Creando las lineas
                for ($j=0; $j<9; $j++)
                {
                    // Verifica que no sea 0
                    if ($columnas[$j][0]>0)
                    {
                        // Lo Agrega a la Linea
                        array_push($linea3,$columnas[$j][0]);
                    }
                }

                // Desplegando la linea
                print_r($linea3);
                echo "<br><br>";
                
            }
        }   
        else
        {
           // Mensaje de Error
           echo "Solo puedes tener entre 3 y 5 cartones para el Juego ...<br>";
        }            
    }

    // Genera las posiciones para las 90 bolas
    function generaBolas()
    {
        // Pasa el numero a las 3 lineas
        for ($x = 0; $x < 90; $x++) 
        {
            // Todos en false
            $bolas[$x] = FALSE;
        }
    }

    // Método bola
    function bola()
    {
        // Resultado
        $resultado = 0;
        
        // Ciclo para Generar el Numero Aleatorio
        while(TRUE)
        {
            // Obtiene el numero aleatorio
            $aleatorio = rand(0,89);

            // Verifica que no haya ya salido
            if (!$bolas[$aleatorio])
            {
                // Sale del Ciclo
                break;
            }
        }
        // Incrementa en 1
        $aleatorio++;

        // Pasa el numero a cada uno de los cartones
        $lineasCompletas = $cartones[0]->marcar($aleatorio);

        // Verifica si ya hizo bingo
        if ($cartones[0]->bingo())
        {
            // Mensaje
            echo "El Primer Cartón ha hecho bingo !!!";
            
            // Coloca que este es el carton que ha hecho bingo primero
            $resultado = 1;
        }

        
        // Pasa el numero a cada uno de los cartones
        $lineasCompletas = $cartones[1]->marcar($aleatorio);

        // Verifica si ya hizo bingo
        if ($cartones[1]->bingo())
        {
            // Mensaje
            echo "El Segundo Cartón ha hecho bingo !!!";

            // Verifica que no haya hecho bingo el previo
            if ($resultado == 0)
               // Coloca este carton como resultado
               $resultado = 2;

        }

        // Pasa el numero a cada uno de los cartones
        $lineasCompletas = $cartones[2]->marcar($aleatorio);

        // Verifica si ya hizo bingo
        if ($cartones[2]->bingo())
        {
            // Mensaje
            echo "El Tercer Cartón ha hecho bingo !!!";
            
            // Verifica que no haya hecho bingo el previo
            if ($resultado == 0)
                // Coloca este carton como resultado
                $resultado = 2;
        }

        // Retorna el resultado
        return $resultado;
    }

    // Método getter de Cartones
    function getCartones()
    {
        // Retorna las lineas
        return $this->cartones;
    }

    // Método getter de Bolas
    function getBolas()
    {
        // Retorna las bolas
        return $this->bolas;
    }

    // Método getter de linea Cantadas
    function getLineaCantada()
    {
        // Retorna la linea cantada
        return $this->lineaCantada;
    }

    // Método setter por carton
    function setCartones($indiceCarton,$valoresDelcarton)
    {
        // Retorna las lineas
        $this->cartones[$indiceCarton]= $valoresCarton;
    }

    // Método setter de Bolas
    function setBolas($bolas)
    {
        // Retorna las bolas
        $this->bolas = $bolas;
    }

    // Método setter de linea Cantadas
    function setLineaCantada($valor)
    {
        // Retorna la linea cantada
        $this->lineaCantada = $valor;
    }    

    // ----------------------------------------------
    // Métodos tomadas del código proporcionado
    // ----------------------------------------------

    // Esta función la genere para iniciar el código
    function generarCarton()
    {
        // Acá inicia el código
        $posicionBorrada=0;
        $filas=[];

        //borramos las posiciones de las columnas
        for($i=0; $i<9 ;$i++){
            $column=$this->generarColumna($i);

            if($i==0){
                $posicionBorrada=rand(0,2);
                $column[$posicionBorrada]=0;
            }else{
                $posicionBorrada+=rand(1,2);
                switch($posicionBorrada){
                    case 0:
                    case 3:
                        $posicionBorrada=0;
                        $column[$posicionBorrada]=0;
                        break;
                    case 1: 
                    case 4:
                        $posicionBorrada=1;
                        $column[$posicionBorrada]=0;
                        break;
                    case 2:
                        $posicionBorrada=2;
                        $column[$posicionBorrada]=0;
                        break;
                }
            }
            array_push($filas,$column);
        }

        $soloUnaPosicion=$this->generarNumeroAleatorioFila($filas);
        foreach($soloUnaPosicion as $posicion){
            $filas[$posicion[1]][$posicion[0]]=0;

        }
                
        // Dibuja el Carton
        $this->pintarTabla($filas);

        // Retorna las filas generadas
        return $filas;
        
    }

    //FUNCIONES: 
    function generarNumeroAleatorioFila($filas){
        $filaColumna=[];
        $fila1=0;
        $fila2=0;
        $fila3=0;
        for($fila=0;$fila<3;$fila++){
            for($columna=0;$columna<9;$columna++){
                if($filas[$columna][$fila]==0){
                switch($fila){
                    case 0:
                        $fila1++;
                    break;
                    case 1:
                        $fila2++;
                    break;
                    case 2:
                        $fila3++;
                    break;
                }
                }
            }
        }
        $fila1=4-$fila1;
        $fila2=4-$fila2;
        $fila3=4-$fila1;

        for($contador=3 ; $contador>0; $contador--){
            $fila;
            if($fila1>0){
                $fila=0;
                $fila1--;
            }else {
                if($fila2>0){
                    $fila=1;
                    $fila2--;
                }else{
                    $fila=2;
                    $fila3--;
                }
            }

            $filaColumnaAux=[];
            $repetido=true;
            
            do{
                $numero= rand(0,8);
                if($filas[$numero][$fila]!=0 && $this->noRepetido($filaColumna, $fila,$numero) ){
                    $repetido=false;
                    array_push($filaColumnaAux,$fila);
                    array_push($filaColumnaAux,$numero);
                }
            }while($repetido);
           array_push($filaColumna, $filaColumnaAux);   
        }
        return  $filaColumna;
    }

    function noRepetido($filaColumnaAux, $fila,$numero){
        foreach($filaColumnaAux as $columna){
            if($columna[1] == $numero){
                return false;
            }
        }
        return true;
    }

    function pintarTabla($filas){
        echo "<table>";      
                for($i=count($filas[0])-1; $i>=0;$i--){
                    echo "<tr>";

                    for($o=0; $o<count($filas); $o++){
                        if($filas[$o][$i]!=0){
                                echo "<td>".$filas[$o][$i]."</td>";

                        }else{
                            echo "<td></td>";
                        }
                    }
                    echo "</tr>";
                }
        echo "</table>";   
        
        // Agregue un cambio de linea JAOR
        echo "<br>"   ;
    }
    
    function generarColumna($startRange){
        $column=[];
        for($i=0; $i<3 ;$i++){
            array_push($column, $this->generarNumeroAleatorio($column, $startRange));
        }
        sort($column);
        return $column;
    }
    
    function generarNumeroAleatorio($column, $startRange){
        $exist=true;
        $number=99999;
        do{
        $number=rand(($startRange*10>0) ? $startRange*10 : 1 ,$startRange*10+9);
            if(!in_array($number,$column)){
                $exist=false;
            }
        }while($exist);
        return $number;
    }

    // -------------------------------------------
}

// Crea un objeto de Juego con 3 carton
$juego = new Juego(4);





echo "Test ejecutado ...<br>";


// echo sprintf("%'.03d", -3);
// echo "<br>";
// echo sprintf("%'.03d", +3);
// echo "<br>";
?>