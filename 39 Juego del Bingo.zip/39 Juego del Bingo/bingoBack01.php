<?php

// -------------------------------------------
// bingo.php
// archivo de clases
// -------------------------------------------

// Definimos la Clase Linea
class Linea
{
        // Atributos
        private $numeros  = array(0,0,0,0,0);
        private $marcados = array(false,false,false,false,false);
        
        // Constructor
        // Aca tengo la duda de si debe recibir los 5 numeros por separado
        // o tambien recibe un arreglo; los puse separados
        function __construct($num1,$num2,$num3,$num4,$num5)
        {
            // Coloca los numeros en el arreglo
            $this->$numeros[0] = $num1;
            $this->$numeros[1] = $num2;
            $this->$numeros[2] = $num3;
            $this->$numeros[3] = $num4;
            $this->$numeros[4] = $num5;
        }

        // Método para marcar
        function marcar($numero)
        {
            // Verifica que el $numero exista en $numeros
            for ($x = 1; $x <= 5; $x++) 
            {
                // Verifica si corresponde al numero
                if ($this->$numeros[$x]==$numero)
                {
                    // Coloca su correspondiente en true en $marcados
                    $this->$marcados[$x]==TRUE;

                    // Sale del Ciclo
                    break;
                }
            }                        
        }

        // Método completo
        function completo()
        {
            // Variable para el resultado
            $resultado = TRUE;
            
            // Ciclo para verificar si todos los marcados son True
            for ($x = 1; $x <= 5; $x++) 
            {
                // Verifica si corresponde al numero
                if (!$this->$marcados[$x])
                {            
                    // Coloca en FALSE el resultado
                    $resultado = FALSE;

                    // Sale del Ciclo
                    break;
                }
            }
            
            // Devuelve el resultado
            return $resultado;
        }

        // No se si en esta clase, tengo que definir los setter's y getter's de los
        // atributos. Supuse que no; porque dice "estos métodos deben crearse en las
        // sucesivas clases". Pero el constructor si había que definirlo
        
}

// Definimos la Clase Carton
class Carton
{
    // Atributos acá creo las 3 lineas inicialmente con 0's
    private $lineas;

    // Constructor
    function __construct()
    {
        // Debe crear las 3 lineas con numeros
    }

    // Método para marcar
    function marcar($numero)
    {
        // Contador de lineas completas
        $lineasCompletas = 0;

        // Pasa el numero a las 3 lineas
        for ($x = 1; $x <= 3; $x++) 
        {
            // Pasa el Numero a las 3 lineas
            $lineas[$x]->marcar($numero)            

            // Verifica si está completa
            if ($lineas[$x]->completo())
            {
                // Incrementa el Contador
                $lineasCompletas++;
            }
        }                        
        
        // Retorna las lineas completas
        return $lineasCompletas;
    }

    // Método bingo
    function bingo($numero)
    {
        // Variable para el resultado
        $resultado = TRUE;

        // Pasa el numero a las 3 lineas
        for ($x = 1; $x <= 3; $x++) 
        {
            // Verifica si NO está completa
            if (!$lineas[$x]->completo())
            {
                // Cambia el resultado a false
                $resultado = FALSE;

                // Sale del Ciclo
                break;
            }
        }
        
        // Retorna las lineas completas
        return $resultado;
    }
}

// Definimos la Clase Juego
class Juego
{
     // Crea un arreglo de 3 cartones
    private $cartones = array(new Carton(),new Carton(),new Carton());

    // Bolas que ya han salida
    private $bolas;

    // Linea Cantada
    private $lineaCantada;

    // Constructor
    function __construct()
    {
        // Sin definir por el momento
    }

    // Método bola
    function bola($numero)
    {
        // Resultado
        $resultado = 0;
        
        // Retorna las lineas completas
        return $lineasCompletas;
    }
}

// Probando las Clases al Momento

?>