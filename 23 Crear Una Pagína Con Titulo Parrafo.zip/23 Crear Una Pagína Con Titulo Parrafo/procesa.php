<?php
// ----------------------------------------------------------
// Procesa.php
// Objetivo: Crear una Página
// ----------------------------------------------------------

// Función que construye la pagina
function fnCrearPagina($parrafo, $titulo)
{
	// Creamos la página
	echo "<!DOCTYPE html>\n";
	echo "<html>\n";
	echo "<head>\n";
    echo "<title>$titulo</title>\n";
	echo "</head>\n";
	echo "<body>\n";		
	echo "	<h1>$titulo</h1>\n";
	echo "	<p> $parrafo</p>\n";			
	echo "</body>\n";
	echo "</html>\n";
}

// validamos los datos
if (isset($_POST["parrafo"] ) && 
	isset($_POST['titulo']))
{
	// Obtengo los 2 datos
	$titulo  = $_POST["titulo"];
	$parrafo = $_POST["parrafo"];

	// Llamar, ejecutar, correr, lanzar  a la función
	fnCrearPagina($parrafo, $titulo);   
}
else
{
	echo "Los Datos no llegaron <br>";
}

?>



