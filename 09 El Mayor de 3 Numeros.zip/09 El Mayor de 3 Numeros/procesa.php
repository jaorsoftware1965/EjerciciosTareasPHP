<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Buscar el Mayor de 3 Numeros
// -----------------------------------------------
print_r($_POST);
echo "<br><br>";

//Verifico primero que los datos existan
if (isset($_POST['nmDato1']) &&  
	isset($_POST['nmDato2']) && 
	isset($_POST['nmDato3']))
{
	// Obtenemos los 3 datos
	$dato1 = $_POST['nmDato1'];
	$dato2 = $_POST['nmDato2'];
	$dato3 = $_POST['nmDato3'];

	// // Desplegamos los 3 datos
	echo "El Dato1  es:$dato1<br>";
	echo "El Dato2  es:$dato2<br>";
	echo "El Dato3  es:$dato3<br><br>";

	// Verificando el mayor
	if ($dato1 > $dato2 &&  $dato1 > $dato3 )
	{
		echo "a) El dato1[$dato1] es el mas grande <br>";
	}
	elseif ($dato2 > $dato1 && $dato2 > $dato3 )
	{
        echo "b) El dato2[$dato2] es el mas grande <br>";
	}
	elseif ($dato3 > $dato1 && $dato3 > $dato2 )
	{
        echo "c) El dato3[$dato3] es el mas grande <br>";
	}
	else
	{
		echo "No hay Dato mayor <br>";
	}
}
else
{
	echo "Faltaron datos<br>";
}

echo "Programa Terminado ...";

// if (!(isset($_POST['nmDato1']) &&
// 	  isset($_POST['nmDato2']) &&
//       isset($_POST['nmDato3'])))
// {
// 	echo "Faltaron datos ----------------->>>>><br>";
// 	$x=0;
// 	if (!isset($_POST['nmDato1']))
// 	{
// 		echo "Falto el Primero <br>";
// 		$x++;
// 	}
// 	if (!isset($_POST['nmDato2']))
// 	{
// 		echo "Falto el Segundo <br>";
// 		$x++;
// 	}
// 	if (!isset($_POST['nmDato3']))
// 	{
// 		echo "Falto el Tercero <br>";
// 		$x++;
// 	}
// 	echo "Faltaron:$x datos<br>";
// }
// else
// {
// 	// Obtenemos los 3 datos
// 	$dato1 = $_POST['nmDato1'];
// 	$dato2 = $_POST['nmDato2'];
// 	$dato3 = $_POST['nmDato3'];

// 	// Desplegamos los 3 datos
// 	echo "El Dato1  es:$dato1<br>";
// 	echo "El Dato2  es:$dato2<br>";
// 	echo "El Dato3  es:$dato3<br><br>";

// 	// Verificando el mayor
// 	if ($dato1 > $dato2 && 
// 		$dato1 > $dato3 )
// 	{
// 		echo "El dato1[$dato1] es el mas grande porque: $dato1 > $dato2 y $dato1 > $dato3";
// 	}
// 	elseif ($dato2 > $dato1 &&
// 	        $dato2 > $dato3 )
// 	{
//         echo "El dato2[$dato2] es el mas grande porque: $dato2 > $dato1 y $dato2 > $dato3";
// 	}
// 	elseif ($dato3 > $dato1 &&
// 	        $dato3 > $dato2 )
// 	{
//         echo "El dato3[$dato3] es el mas grande porque $dato3 > $dato1 y $dato3 > $dato2";
// 	}
// 	else
// 	{
// 		echo "No hay Dato mayor";
// 	}
	
// }

?>



