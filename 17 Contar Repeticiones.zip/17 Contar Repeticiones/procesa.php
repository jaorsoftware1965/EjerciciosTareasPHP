<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Obtener valores sin rpetir
// -----------------------------------------------

// Imprimimos el POST
print_r($_POST);
echo "<br><br>";

// Verificamos llegada
if (isset($_POST["datos"]))
{
	// Paso los datos a un vector o aun arreglo
	$datos = explode(",", $_POST["datos"]);

    // Variable Arreglo que va a contar las repeticiones
    $datosRepeticiones = [];

	// Ciclo para recorrer los datos
	foreach ($datos as $valor) 
	{
		// Verifica que no está en el vector
		if (!array_key_exists($valor, $datosRepeticiones))
		{
			// Si no lo encuentra, lo agrega
			$datosRepeticiones[$valor] = 1;
		}
		else
		{
			// Si si lo encuentra, le incrementar el valor en 1
			$datosRepeticiones[$valor]=$datosRepeticiones[$valor] + 1;
		}
	}
	
	// Mensaje Resultados
	echo "Los Datos con Sus Repeticiones son:<br>";

	
	foreach ($datosRepeticiones as $key => $value) 
	{
		echo "[$key]->[$value]<br>";
	}
	echo "<br>";
}
else
{
	// Mensaje
	echo "Los datos no llegaron<br>";
}

// Mensaje Final
echo "Programa Terminado"

?>



