<?php
// ----------------------------------------------------------
// Procesa.php
// Objetivo: Crear una Página
// ----------------------------------------------------------

// Función que construye la pagina
function fnCreaPagina($titulo, $parrafo, $imagen)
{
	// Creamos la página
	echo  "<!DOCTYPE html>\n";
	echo "<html>\n";
	echo "<head>\n";
    echo "<title>$titulo</title>\n";
	echo "</head>\n";
	echo "<body>\n";		
	echo "	<h1>$titulo</h1>\n";
	echo "	<p> $parrafo</p>\n";			
	echo "	<img src='$imagen' width=200>\n";			
	echo "</body>\n";
	echo "</html>\n";
}

// validamos los datos
if (isset($_POST["imagen"] ))
{
	// Obtengo los 2 datos
	$imagen  = $_POST["imagen"];

	// Llama a la función
	fnCreaPagina("Pagina con Imagen","Esta es la Imagen",$imagen);   
}
else
{
	echo "Los Datos no llegaron <br>";
}

?>



