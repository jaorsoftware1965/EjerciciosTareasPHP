<?php

// Imprime el POST
print_r($_POST);
echo "<br><br>";

// Verifica que haya llegado
if (isset($_POST["lista"]))
{
	// Contar Elementos
	$cuentaElementos = 0;

	// Cuantos son numeros
	$cuentaNumeros = 0;

	// Contar Pares
	$cuentaPares = 0;

	// Suma de los Numeros
	$sumaNumeros = 0;

	// obtiene los datos
	$listaDatos = explode(",",$_POST["lista"]);

    echo "Arreglo de Datos:<br>";
	print_r($listaDatos);
	echo "<br><br>";

	// Ciclo para recorrer los datos
	foreach ($listaDatos as $valor) 
	{
		// Incrementa el contador de Elementos
		$cuentaElementos++;

		// Verifica si es numero
		if (is_numeric($valor))
		{
			// Incrementa la Suma
            $sumaNumeros += $valor;

			// Incrementa el Contador de Números
			$cuentaNumeros++;

			// Verifica si es par
            if ($valor % 2 == 0)
            	$cuentaPares++;
        }		
	}

	// Despliega los resultados
	echo "Elementos en la lista: $cuentaElementos<br>";
    echo "Numeros   en la lista: $cuentaNumeros<br>";
    echo "Pares     en la lista: $cuentaPares<br>";
    echo "Impares   en la lista: ".($cuentaNumeros-$cuentaPares);
    echo "<br>";
    echo "La suma de los Números es: $sumaNumeros<br>";
    echo "El Promedio de los Numeros es:";
    if($cuentaNumeros>0) 
    	echo $sumaNumeros / $cuentaNumeros;
    else
    	echo "No se puede obtener el promedio";
    echo "<br><br>";
}
else
{
	echo "No llegaron los datos<br>";
}

// Mensjae
echo "Programa Terminado<br>";


?>