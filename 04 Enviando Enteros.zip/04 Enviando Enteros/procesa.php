<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Verificando si un dato es Entero
// -----------------------------------------------

print_r($_POST);
echo "</br></br>";

// Verifico primero que el dato exista
if (isset($_POST['nmDato']))
{
	// Obtengo el Dato
	echo "El Dato recibido es:<br>";
	$dato = $_POST['nmDato'];
    echo $dato,"</br>";

    // Verifica si es numero
    if (is_numeric($dato))
    {
    	// Lo trata de convertir a un entero
        $entero = intval($dato);

        // Verifica si es entero
        if (is_integer($entero))
        {
            // Obtengo el flotante
            $flotante = floatval($dato);

            if ($entero == $flotante)
            {
               echo "El Dato enviado SI es Entero y es:$entero";    
            }
            else
            {
               echo "El Dato enviado SI Se pudo convertir a Entero pero es   Flotante, y es:$flotante";
            }            
        }
        else
        {
            echo "El Dato enviado NO es Entero";
        }
    }
    else
    {
    	echo "El dato no es numerico";
    }    
}
else
{
	echo "El Dato esperado no se pudo obtener";
	echo "Verifica que el name del dato sea EXACTAMENTE: 'nmDato'";
}
echo "<br>Programa Terminado ...";
?>