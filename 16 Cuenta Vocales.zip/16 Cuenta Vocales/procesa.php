<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Desplegar un timer
// -----------------------------------------------

// Desplegamos el Arreglo
print_r($_POST);
echo "<br><br>";

// Verifico primero que el dato exista
if (isset($_POST['texto']) && isset($_POST['vocal']))
{
	// Obtengo los datos
	$texto = strtoupper($_POST['texto']);
	$vocal = $_POST['vocal'];	
	
	// Obtiene la 
	$cuenta = substr_count($texto, $vocal);

	// Despliega
	echo "El Numero de vocales es :$cuenta<br><br>";
}
else
{	
	echo "No llegaron los datos esperados<br>";
}

// Mensaje Final
echo "Programa Terminado ...";


?>


