<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Desplegar el dato desde el Formulario
// -----------------------------------------------

print_r($_POST);
echo "<br><br>";

// Verifico primero que el dato exista
if (isset($_POST['nmDato']))
{
    // Pasarlo a una variable
    $dato = $_POST['nmDato'];

	// Obtengo el Dato
	echo "El Dato recibido es:<br>";
    echo $dato;
    echo "</br>";

    // Eliminamos los espacios
    $dato = str_replace(" ", "", $dato);
    echo "El dato sin espacios:$dato<br><br>";

    // Convertir a Minusculas
    $dato = strtolower($dato);
    echo "El dato en minusculas:$dato<br><br>";

    // Obtenemos el reverso del dato
    $reverso = strrev($dato);
    echo "El Reverso del dato:$reverso<br><br>";
    
    // Comparamos
    if ($reverso==$dato) 
    {
    	echo "El Dato [$dato] si es palindromo";
    }
    else
    {
        echo "El Dato [$dato] no es palindromo";
    }
}
else
{
	echo "El Dato esperado no se pudo obtener<br>";
	echo "Verifica que el name del dato sea EXACTAMENTE: 'nmDato'";
}

?>



