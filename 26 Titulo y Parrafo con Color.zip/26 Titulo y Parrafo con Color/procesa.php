<?php

// Función para crear un párrafo con Color
function fnCreaH1ConColor($titulo,$colorTitulo)
{
	// Crea el H1
    echo "<h1 style ='color:$colorTitulo'>$titulo</h1>\n";
}

// Función para crear un párrafo con Color
function fnCreaParrafoConColor($parrafo,$colorParrafo)
{
	// Crea el Párrafo
    echo "<p style ='color:$colorParrafo'>$parrafo</p>\n";
}

// Función que construye la pagina
function fnCreaPagina($titulo, $colorTitulo, $parrafo, $colorParrafo)
{
	// Creamos la página
	echo  "<!DOCTYPE html>\n";
	echo "<html>\n";
	echo "<head>\n";
    echo "<title>$titulo</title>\n";
	echo "</head>\n";
	echo "<body>\n";

	// Llama la función para crear el Título		
	fnCreaH1ConColor($titulo,$colorTitulo);

	// Llama la función para crear el Párrafo		
	fnCreaParrafoConColor($parrafo,$colorParrafo);
		
    // Cierro el Body y el Html
	echo "</body>\n";
	echo "</html>\n";
}


// validamos los datos
if (isset($_POST["titulo"] )     && 
	isset($_POST["tituloColor"]) &&
    isset($_POST["parrafo"])     && 
    isset($_POST["parrafoColor"]))
{
	// Obtengo los 4 datos
	$titulo       = $_POST["titulo"];
	$tituloColor  = $_POST["tituloColor"];
	$parrafo      = $_POST["parrafo"];
	$parrafoColor = $_POST["parrafoColor"];

	// Llama a la función
	fnCreaPagina($titulo, $tituloColor, $parrafo, $parrafoColor);   
}
else
{
	echo "Los Datos no llegaron <br>";
}

?>