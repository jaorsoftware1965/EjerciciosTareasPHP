<?php
// -----------------------------------------------
// Procesa.php
// -----------------------------------------------

// Mensaje
echo "El POST<br>";
print_r($_POST);
echo "</br>";
echo "Elementos en el POST:".count($_POST);
echo "</br></br>";

// Variable para la suma y aprobados
$suma      = 0;
$aprobados = 0;


// Arreglo de Calificaciones Aprobatorias
$indice    = 0;

// Ciclo para desplegar los datos
foreach ($_POST as $calificacion) 
{
	// Suma la calificación
	$suma += $calificacion;
    
    // Verifica si es aprobatoria
    if ($calificacion>=60)
    {
    	// Incrementa el Contador de Aprobados
    	$aprobados++;

    	// Lo Agrega al Vector
    	$calificaciones[$indice++] = $calificacion;
    }

    // Verifica calificacion maxima exista
    if (!isset($maxima))
    {
    	// Coloca la primera califacion
    	$maxima = $calificacion;    	
    }
    else
    {
    	// Compara
    	if ($maxima < $calificacion)
    		$maxima = $calificacion;
    }
    	
    
    // Verifica calificacion maxima exista
    if (!isset($minima))
    {
    	// Coloca la primera califacion
    	$minima = $calificacion;
    }
    else
    {    	
    	// Compara
    	if ($minima > $calificacion)
    		$minima = $calificacion;
    }	
}


// Desplegamos el valor de la Suma
echo "La Suma de las Calificaciones es:$suma <br>";
echo "La Calificacion Máxima es:$maxima <br>";
echo "La Calificacion Minima es:$minima <br>";

// El Promedio
$promedio = $suma / count($_POST);
echo "El Promedio de las Califaciones es:$promedio <br>";

echo "Las Calificaciones Aprobatorias son $aprobados:<br>";
foreach ($calificaciones as $valor) 
{
    echo "[$valor]";
}
echo "<br>";

echo "Las Califaciones No Aprobatorias son :";
echo count($_POST)-$aprobados."<br>";



echo "<br>Programa terminado.";

?>



