<?php
// ----------------------------------------------------------
// Procesa.php
// Objetivo: Verificando la Fecha y obteniendo su informacion
// ----------------------------------------------------------

// Desplegando el Arreglo de la Variable $_POST
print_r($_POST);   // Primer Paso
echo "<br>";echo "<br>";

// Verifico primero que los datos existan
if (isset($_POST['nmFecha']) && isset($_POST['nmHora'])) // Segundo paso
{
    // Paso los datos a una variable
    $fecha = $_POST['nmFecha']; // Tercer paso
    $hora  = $_POST['nmHora'];

    // Intentamos crear una fecha con los datos recibidos
    $fechaTimeStamp = strtotime($fecha.$hora);
    echo "Valor Numerico en Segundos de la Fecha:".$fechaTimeStamp;
    echo "</br>";

    // Desplegando la fecha Convertida
    echo "Fecha en 12 hrs: ";
    echo date("d-m-y h.i.s a",$fechaTimeStamp);
    echo "<br>";

    echo "Nombre del dia es :" . date("l",$fechaTimeStamp). "<br>";
    echo "Dia de la Semana  :" . date("w",$fechaTimeStamp). "<br>";
    echo "Dia del año       :" . date("z",$fechaTimeStamp). "<br>";
    echo "La Semana      es :" . date("W",$fechaTimeStamp)."<br>";
    echo "<br>";
    
}
else
{
	echo "Los datos no llegaron<br>";
}

echo "Programa Terminado ...";

?>



