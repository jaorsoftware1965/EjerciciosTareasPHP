<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Desplegar un timer
// -----------------------------------------------

// Desplegamos el Arreglo
print_r($_POST);
echo "<br><br>";


// Verifico primero que el dato exista
if (isset($_POST['incremento']) && 
	isset($_POST['inicial']) &&
    isset($_POST['final']))
{
	// Obtengo los datos	
	$inicial    = $_POST['inicial'];
	$final      = $_POST['final'];
	$incremento = $_POST['incremento'];

	
	// Desplegando la tabla
	for ($x=$inicial; $x <= $final; $x+=$incremento)
	{
		// Desplegamos la operación
		echo "[$x] ";
	}
	echo "<br>";
	
}
else
{	
	echo "No llegaron los datos esperados";
}

echo "<br>Programa Terminado"

?>



