<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Analizar Pares e Impares
// -----------------------------------------------
// Mensaje
print_r($_POST);
echo "<br><br>";

// Variable para analizar
$pares       = 0;
$sumaPares   = 0;

$impares     = 0;
$sumaImpares = 0;

$errores     = 0;


// Valida los datos
if (isset($_POST["datos"]))
{
	// Pasa los datos a una arreglo
	$datos = explode(",", $_POST["datos"]);

	// Ciclo para procesar los datos
	foreach ($datos as $valor) 
	{
		// Pregunto si no es numero
		if (!is_numeric($valor))
		{
			// Incremento la variable de Errores
			$errores++;
		}
		else
		{
			// Verifica si es par
		    if ($valor % 2 == 1)
		    {
		    	// Incrementamos y sumamos
		       $impares++;	
		       $sumaImpares+=$valor;
		       
		    }   
		    else
		    {
		    	// Incrementamos y sumamos
		       $pares++;	
		       $sumaPares+=$valor;		       
		    }
		}	    
	}
	
	// Desplegamos los pares
    echo "La cantidad de pares es:$pares <br>";
    echo "La suma de los pares es:$sumaPares <br><br>";
    
    echo "La cantidad de impares es:$impares <br>";
    echo "La suma de los impares es:$sumaImpares <br><br>";
    
    echo "La cantidad de datos es:".($pares + $impares)."<br>";
    echo "La suma general es:".($sumaPares + $sumaImpares)."<br>";

    echo "Los datos erroneos:$errores<br><br>";

}
else
{
	echo "Los Datos no llegaron <br>";
}

echo "Programa Finalizado ...";


?>



