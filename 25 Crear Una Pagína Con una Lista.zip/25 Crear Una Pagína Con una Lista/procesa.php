<?php
// ----------------------------------------------------------
// Procesa.php
// Objetivo: Crear una Página
// ----------------------------------------------------------

// Función que construye la pagina
function fnCreaPagina($titulo, $parrafo, $lista)
{
	// Creamos la página
	echo  "<!DOCTYPE html>\n";
	echo "<html>\n";
	echo "<head>\n";
    echo "<title>$titulo</title>\n";
	echo "</head>\n";
	echo "<body>\n";		
	echo "	<h1>$titulo</h1>\n";
	echo "	<p> $parrafo</p>\n";			
	
	// Obtengo el arreglo de opciones de la lista
	$opciones = explode(",",$lista);

    // Crea la etiqueta de listas 
    echo "    <ul>\n";

    foreach ($opciones as $valor) 
    {
    	echo "      <li>$valor</li>\n";
    }

	// Cierro la etiqueta de la lista
	echo "    </ul>\n";

    // Cierro el Body y el Html
	echo "</body>\n";
	echo "</html>\n";

}

// validamos los datos
if (isset($_POST["lista"] ))
{
	// Obtengo el dato
	$lista  = $_POST["lista"];

	// Llama a la función
	fnCreaPagina("Pagina con Lista","Esta es la Lista",$lista);   
}
else
{
	echo "Los Datos no llegaron <br>";
}

?>



