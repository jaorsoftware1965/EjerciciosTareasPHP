<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Verificar si un dato es numérico
// -----------------------------------------------

// Imprimir el Arreglo POST
print_r($_POST);
echo "<br><br>";

// Verifico primero que el dato exista
if (isset($_POST['nmDato'])) // Si existe nmDato en el Arreglo POST
{
    // Paso el Dato a una variable
    $dato = $_POST['nmDato'];

	// Lo despliego
	echo "El Dato recibido es:<br>";	
    echo $dato,"</br>";    

    // Verifica si es numero
    if (is_numeric($dato))
    {
    	echo "El Dato SI es un número<br>";        
    }
    else
    {
    	echo "El dato NO es un número<br>";
    }    
}
else // Si no existe
{
	echo "El Dato esperado no llegó<br>";
}

// Fin del Programa
echo "Programa Finalizado ...";

?>