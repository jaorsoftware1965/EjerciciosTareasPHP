<?php

// Función para crear un párrafo con Color
function fnCreaH1ConColor($titulo,$color)
{
	// Crea el H1
    echo "<h1 style ='color:$color'>$titulo</h1>\n";
}

// Función para crear un párrafo con Color
function fnCreaParrafoConColor($parrafo,$color)
{
	// Crea el Párrafo
    echo "<p style ='color:$color'>$parrafo</p>\n";
}

// Función para crear un párrafo con Color
function fnCreaTabla($renglones,$columnas,$caption,$alineacion)
{
	// Crea la tabla
    echo "<table style='border:1px solid black; width:100%'>\n";
    echo "<caption ";
    if ($alineacion=="derecha")
    {
    	echo  "style='text-align:right'";
    }
    elseif ($alineacion=="izquierda")
    {
       echo  "style='text-align:left'";	
    }
    echo ">\n    $caption\n</caption>\n";

    // Ciclo para los renglones
    for ($i=0; $i < $renglones ; $i++) 
    { 
    	// Creo el renglon
    	echo "<tr>\n";

    	// Ciclo para cada celda
    	for ($j=0; $j < $columnas ; $j++) 
    	{ 
    		echo "<td style='border:1px solid black'>[$i,$j]</td>\n";
    	}
        // Cierro el Renglon
    	echo "</tr>\n";
    }

    // Cierra la Tabla
    echo "</table>\n";
}

// Función que construye la pagina
function fnCreaPagina($titulo, 
	                  $parrafo, 
	                  $renglones, 
	                  $columnas,
	                  $caption,
	                  $alineacion)
{
	// Creamos la página
	echo  "<!DOCTYPE html>\n";
	echo "<html>\n";
	echo "<head>\n";
    echo "<title>$titulo</title>\n";
	echo "</head>\n";
	echo "<body>\n";

	// Llama la función para crear el Título		
	fnCreaH1ConColor($titulo,"red");

	// Llama la función para crear el Párrafo		
	fnCreaParrafoConColor($parrafo,"blue");

	// Crea la tabla
	fnCreaTabla($renglones, $columnas,$caption,$alineacion);
		
    // Cierro el Body y el Html
	echo "</body>\n";
	echo "</html>\n";
}

// Acá empieza la ejecución

// validamos los datos
if (isset($_POST["renglones"]) && 
    isset($_POST["columnas" ]) &&
    isset($_POST["caption" ]) &&
    isset($_POST["alineacion"]))
{
	// Obtengo los 2 datos
	$renglones  = $_POST["renglones"];
	$columnas   = $_POST["columnas"];
	$caption    = $_POST["caption"];
	$alineacion = $_POST["alineacion"];

	// Llama a la función
	fnCreaPagina("Pagina con Tabla y Caption", 
		         "Esta es la tabla", 
		         $renglones, 
		         $columnas,
		         $caption,
		         $alineacion);   
}
else
{
	echo "Los Datos no llegaron <br>";
}

?>