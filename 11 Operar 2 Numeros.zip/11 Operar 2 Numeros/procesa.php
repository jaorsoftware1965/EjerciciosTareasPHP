<?php

print_r($_POST);
echo "<br><br>";

// Verifico primero que los datos existan
if (isset($_POST['operador'])&&
	isset($_POST['nmDato1'] ) && 
	isset($_POST['nmDato2'] ))
{
	// Obtengo los datos
	$dato1 = $_POST['nmDato1'];
	$dato2 = $_POST['nmDato2'];
	$op    = $_POST['operador'];

	// Vºerifica que operación realizar
	if ($op =='+')
	{
		// Ejecuta Suma
	    $resultado = $dato1 + $dato2;

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";
	}
	elseif ($op =='-')
	{
	    // Ejecuta Resta
	    $resultado = $dato1 - $dato2;

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";	
	}
	elseif ($op =='*')
	{
	    // Ejecuta Multiplicación
	    $resultado = $dato1 * $dato2;

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";		
	}
	elseif ($op =='/')
	{
		// Ejecuta Multiplicación
	    $resultado = $dato1 / $dato2;

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";	

	}
	else
	{
		// MEnsaje de Operador Desconocido
		echo "El operador :$op no es conocido";
	}
}
else
{
	echo "Faltan datos en el Envio<br>";
}

echo "<br>Programa Terminado ";

?>



