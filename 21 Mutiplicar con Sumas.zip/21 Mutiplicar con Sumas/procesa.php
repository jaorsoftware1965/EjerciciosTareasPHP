<?php
// ---------------------------------------------------
// Procesa.php
// Objetivo: Multiplicar 2 numeros con sumas sucesivas
// ---------------------------------------------------

// Desplegamos el Post
print_r($_POST);
echo "<br><br>";

// validamos los datoa
if (isset($_POST["dato1"]) && isset($_POST['dato2']))
{
	// Obtengo los 2 datos
	$dato1 = $_POST["dato1"];  // Es el numero que se repote
	$dato2 = $_POST["dato2"];  // SOn las veces que se repite

    // Variable para el resultado
    $resultado = 0;

	// Realizo la multiplicacion
	for ($i=0; $i < $dato2 ; $i++) 
	{ 
	    // Suma e imprime
	    $resultado += $dato1;
	    echo "Resultado:$resultado<br>";	    
	}    
	echo "<br>";

    // Inicializo resultado
    $resultado = 0;

	// Realizo la multiplicacion
	for ($i=0; $i < $dato1 ; $i++) 
	{ 
	    // Suma e imprime
	    $resultado = $resultado + $dato2;
	    echo "Resultado:$resultado<br>";	    
	}    
	echo "<br>";
}
else
{
	echo "Los Datos no llegaron <br>";
}

// Fin del Programa
echo "Programa terminado ...";


?>



