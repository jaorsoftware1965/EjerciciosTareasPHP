<?php  
// -----------------------------------------------------
// insertarAlumno.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['noControl']) && 
    isset($_GET['carrera'])   && 
    isset($_GET['nombre'])    &&
    isset($_GET['paterno'])   &&
    isset($_GET['materno'])   &&
    isset($_GET['direccion']) &&
    isset($_GET['correo'])    &&
    isset($_GET['telefono'])
   )
{
	// Obtiene los datos
	$noControl    = $_GET['noControl'];
    $carrera      = $_GET['carrera'];
	$nombre       = $_GET['nombre'];
	$paterno      = $_GET['paterno'];
	$materno      = $_GET['materno'];
    $direccion    = $_GET['direccion'];
    $correo       = $_GET['correo'];
	$telefono     = $_GET['telefono'];

	// Prepara el Query para la Inserción
	$query  = " INSERT INTO alumnos ";
	$query .= " (noControl, id_carrera, nombre, apellidoPaterno, apellidoMaterno, direccion, email, telefono)";
	$query .= " VALUES ";
	$query .= " ($noControl,$carrera,'$nombre','$paterno','$materno','$direccion','$correo','$telefono')";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Verifica
	if ($registros)
	{   
	    // Variables para el Error
	    echo "ok";
	}   
	else
	{   
	    echo "Error.".mysqli_errno($conexion) . ": " . mysqli_error($conexion) . "\n";
	}
}
else
{
   echo "Faltaron datos en la consulta";
}
?>