<?php  
// -----------------------------------------------------
// cargarAlumnos.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Preparando el Query para la Consulta
$query = "SELECT * FROM alumnos ORDER BY nombre";

// Ejecuta Query y obtiene Registros
$registros = $conexion->query($query);

// Vaerifica que hay registros
if ($registros)
{   
    // Despliega la creación de las opciones 
    echo "<option value=''    >Seleccione el Alumno</option>";
    // Ciclo para procesar cada registro de usario
    while ($fila = $registros->fetch_assoc()) 
    { 
      $nombreCompleto  = $fila['nombre']." ".$fila['apellidoPaterno']." ".$fila['apellidoMaterno']."-";
      $nombreCompleto .= $fila['email']."-".$fila['telefono'];
      echo "<option value=".$fila['noControl'].">".$nombreCompleto."</option>";
    }
}
else
{
   echo $conexion->error();
}
?>