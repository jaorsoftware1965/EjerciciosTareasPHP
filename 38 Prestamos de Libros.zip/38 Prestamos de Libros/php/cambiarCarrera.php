<?php  
// -----------------------------------------------------
// cambiarCarrera.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['id'])    && 
    isset($_GET['nombre']))
{
	// Obtiene los datos
	$id     = $_GET['id'];
	$nombre = $_GET['nombre'];

	// Prepara el Query para la Modificación
	$query  = " UPDATE carreras SET";
	$query .= " nombre  = '$nombre'";
	$query .= " WHERE id_carrera = $id";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Vaerifica que hay registros
    if ($registros)
    {    
        // Verifica si afecto
        if (mysqli_affected_rows($conexion)>0)        
           $resultado = "ok";      
        else        
           $resultado = "No hubo cambios que realizar";        
	}  
    else
       // Error
       $resultado = $conexion->error;

    echo $resultado;
}
else
{
   echo "Faltaron datos en la consulta";
}


?>