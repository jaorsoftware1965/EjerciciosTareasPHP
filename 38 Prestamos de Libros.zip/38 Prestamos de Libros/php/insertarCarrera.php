<?php  
// -----------------------------------------------------
// insertarCarrera.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['id']) && 
    isset($_GET['nombre']))
{
	// Obtiene los datos
	$id     = $_GET['id'];
	$nombre = $_GET['nombre'];	

	// Prepara el Query para la Inserción
	$query  = " INSERT INTO carreras ";
	$query .= " (id_carrera, nombre)";
	$query .= " VALUES ";
	$query .= " ('$id','$nombre')";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Verifica
	if ($registros)
	{   
	    // Variables para el Error
	    echo "ok";
	}   
	else
	{   
	    echo "Error.".mysqli_errno($conexion) . ": " . mysqli_error($conexion) . "\n";
	}
}
else
{
   echo "Faltaron datos en la consulta";
}


?>