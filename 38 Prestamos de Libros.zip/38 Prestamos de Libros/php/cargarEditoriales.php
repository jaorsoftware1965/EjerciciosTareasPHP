<?php  
// -----------------------------------------------------
// cargarEditoriales.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";


// Preparando el Query para la Consulta
$query = "SELECT * FROM editoriales ORDER BY nombre";

// Ejecuta Query y obtiene Registros
$registros = $conexion->query($query);

// Vaerifica que hay registros
if ($registros)
{   
    // Despliega la creación de las opciones 
    echo "<option value=''>Seleccione la Editorial</option>";
    // Ciclo para procesar cada registro de usario
    while ($fila = $registros->fetch_assoc()) 
    { 
      echo "<option value=".$fila['id_editorial'].">".$fila['nombre']."</option>";
    }
}
else
{
   echo $conexion->error();
}
?>