<?php  
// -----------------------------------------------------
// buscarPrestamos.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

//print_r($_GET);
//echo "<br>";

// Verificamos que hayan llegado los datos
if (isset($_GET['alumno'])   && 
    isset($_GET['libro'])
   )
{

    // Obtenemos los 7 datos
    $alumno   = $_GET['alumno'];
    $libro    = $_GET['libro'];    

    // Preparando el Query para la Consulta
    $query  = " SELECT prestamos.id_prestamo, alumnos.nombre, libros.titulo, ";
    $query .= "        prestamos.fecha_prestamo,prestamos.fecha_vencimiento, prestamos.multa";
    $query .= " FROM   prestamos, alumnos, libros";
    $query .= " WHERE  prestamos.id_libro  = libros.id_libro";
    $query .= " AND    prestamos.noControl = alumnos.noControl";

    // Verificamos si hay alumno a incluir
    if (strlen($alumno)>0)
    	$query .= " AND prestamos.noControl = '".$alumno."'";

    // Verificamos si hay libro a incluir    
    if (strlen($libro)>0)
       	$query .= " AND prestamos.id_libro = ".$libro;

    
    // Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Vaerifica que hay registros
	if ($registros)
	{    
	    // Ciclo para procesar cada registro de usario
        while ($fila = $registros->fetch_assoc()) 
        { 
           // Despliega los datos
           echo "<tr>";
           		echo "<td>".$fila['id_prestamo']      ."</td>";
           		echo "<td>".$fila['titulo']         ."</td>";
           		echo "<td>".$fila['nombre']        ."</td>";
           		echo "<td>".$fila['fecha_prestamo']   ."</td>";
           		echo "<td>".$fila['fecha_vencimiento']."</td>";
           		echo "<td>".$fila['multa']            ."</td>";
           echo "</tr>";
        }
	}  
	else
    {
		echo "<p>No se encontraron registros con el criterio indicado</p>";
    }
}
else
{
   echo "Faltaron datos en la consulta";
}


?>