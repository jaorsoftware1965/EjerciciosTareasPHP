<?php  
// -----------------------------------------------------
// insertarEditorial.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";


// Verificamos que hayan llegado los datos
if (isset($_GET['id'])    && 
    isset($_GET['nombre'])&&
    isset($_GET['pais'])
   )
{
	// Obtiene los datos
	$id     = $_GET['id'];
	$nombre = $_GET['nombre'];
	$pais   = $_GET['pais'];

	// Prepara el Query para la Inserción
	$query  = " INSERT INTO editoriales ";
	$query .= " (id_editorial, nombre, pais)";
	$query .= " VALUES ";
	$query .= " ('$id','$nombre','$pais')";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Verifica
	if ($registros)
	{   
	    // Variables para el Error
	    echo "ok";
	}   
	else
	{   
	    echo "Error.".mysqli_errno($conexion) . ": " . mysqli_error($conexion) . "\n";
	}
}
else
{
   echo "Faltaron datos en la consulta";
}


?>