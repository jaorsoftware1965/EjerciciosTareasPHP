<?php  
// -----------------------------------------------------
// insertarAutor.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['id'])      && 
    isset($_GET['nombre'])  &&
    isset($_GET['paterno']) &&
    isset($_GET['materno']) &&
    isset($_GET['nacionalidad'])
   )
{
	// Obtiene los datos
	$id           = $_GET['id'];
	$nombre       = $_GET['nombre'];
	$paterno      = $_GET['paterno'];
	$materno      = $_GET['materno'];
	$nacionalidad = $_GET['nacionalidad'];


	// Prepara el Query para la Inserción
	$query  = " INSERT INTO autores ";
	$query .= " (id_autor, nombre, apellidoPaterno, apellidoMaterno, nacionalidad)";
	$query .= " VALUES ";
	$query .= " ($id,'$nombre','$paterno','$materno','$nacionalidad')";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Verifica
	if ($registros)
	{   
	    // Variables para el Error
	    echo "ok";
	}   
	else
	{   
	    echo "Error.".mysqli_errno($conexion) . ": " . mysqli_error($conexion) . "\n";
	}
}
else
{
   echo "Faltaron datos en la consulta";
}


?>