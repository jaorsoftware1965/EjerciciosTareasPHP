<?php  
// -----------------------------------------------------
// cargarCarreras.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Preparando el Query para la Consulta
$query = "SELECT * FROM libros ORDER BY titulo";

// Ejecuta Query y obtiene Registros
$registros = $conexion->query($query);

// Vaerifica que hay registros
if ($registros)
{   
    // Despliega la creación de las opciones 
    echo "<option value=''    >Seleccione el Libro</option>";
    // Ciclo para procesar cada registro de usario
    while ($fila = $registros->fetch_assoc()) 
    { 
      echo "<option value=".$fila['id_libro'].">".$fila['titulo']."</option>";
    }
}
else
{
   echo $conexion->error();
}


?>