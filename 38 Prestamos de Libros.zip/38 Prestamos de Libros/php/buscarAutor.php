<?php  
// -----------------------------------------------------
// buscarAutor.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['id']))
{

    // Obtenemos los 7 datos
    $id   = $_GET['id'];    

    // Preparando el Query para la Consulta
    $query  = " SELECT * FROM autores";
    $query .= " WHERE id_autor = ".$id;
    
    
    // Despliega el Query
    //echo $query."<br>";

    // Ejecuta Query y obtiene Registros
	  $registros = $conexion->query($query);

    // Inicializa el Resultado
    $resultado ="ok";

    // Vaerifica que hay registros
	  if ($registros)
	  {    
        // Ciclo para procesar cada registro de usario
        if (mysqli_num_rows($registros)>0)
        { 
           // Lee un Registro
           $fila = $registros->fetch_assoc();

           // agrega los datos al resultado
           $resultado = $resultado .",".$fila['nombre'].",".$fila['apellidoPaterno'].",".$fila['apellidoMaterno'].",".$fila['nacionalidad'];
        }
        else
        {
          $resultado ="No se encontró el autor con el Id indicado";
        }  
	  }  
    else
       // Error
       $resultado = $conexion->error;
       
    // Imprime el Resultado
    echo $resultado;
}
else
{
   echo "Faltaron datos en la consulta";
}

?>