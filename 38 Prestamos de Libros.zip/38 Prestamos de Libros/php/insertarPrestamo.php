<?php  
// -----------------------------------------------------
// insertarPrestamo.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['libro'])       && 
    isset($_GET['alumno'])      && 
    isset($_GET['prestamo'])    &&
    isset($_GET['vencimiento']) &&
    isset($_GET['multa'])
   )
{
	// Obtiene los datos
	$libro        = $_GET['libro'];
    $alumno       = $_GET['alumno'];
	$prestamo     = $_GET['prestamo'];
	$vencimiento  = $_GET['vencimiento'];
	$multa        = $_GET['multa'];

	// Prepara el Query para la Inserción
	$query  = " INSERT INTO prestamos ";
	$query .= " (id_libro, noControl, fecha_prestamo, fecha_vencimiento, multa)";
	$query .= " VALUES ";
	$query .= " ($libro, $alumno, '$prestamo','$vencimiento',$multa)";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Verifica
	if ($registros)
	{   
	    // Variables para el Error
	    echo "ok";
	}   
	else
	{   
	    echo "Error.".mysqli_errno($conexion) . ": " . mysqli_error($conexion) . "\n";
	}
}
else
{
   echo "Faltaron datos en la consulta";
}
?>