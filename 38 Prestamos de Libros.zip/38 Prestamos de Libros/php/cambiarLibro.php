<?php  
// -----------------------------------------------------
// cambiarLibro.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['id']) && 
    isset($_GET['autor'])   &&
    isset($_GET['editorial'])    &&
    isset($_GET['nombre'])   &&
    isset($_GET['edicion'])   &&
    isset($_GET['isbn'])    &&
    isset($_GET['paginas']) &&
    isset($_GET['año'])
   )
{
	// Obtiene los datos
	$id        = $_GET['id'];
    $autor     = $_GET['autor'];
	$editorial = $_GET['editorial'];
	$nombre    = $_GET['nombre'];
    $edicion   = $_GET['edicion'];
    $isbn      = $_GET['isbn'];
    $paginas   = $_GET['paginas'];
    $año       = $_GET['año'];


	// Prepara el Query para la Modificación
	$query  = " UPDATE libros SET";
	$query .= " id_autor       =  $autor,";
    $query .= " id_editorial   =  $editorial,";
    $query .= " titulo         = '$nombre',";
    $query .= " edicion        = '$edicion',";
    $query .= " isbn           = '$isbn',";
	$query .= " noPaginas      = '$paginas',";
    $query .= " annio          = '$año'";
	$query .= " WHERE id_libro =  $id";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Vaerifica que hay registros
    if ($registros)
    {    
        // Verifica si afecto
        if (mysqli_affected_rows($conexion)>0)        
           $resultado = "ok";      
        else        
           $resultado = "No hubo cambios que realizar";        
	}  
    else
       // Error
       $resultado = $conexion->error;

    echo $resultado;
}
else
{
   echo "Faltaron datos en la consulta";
}
?>