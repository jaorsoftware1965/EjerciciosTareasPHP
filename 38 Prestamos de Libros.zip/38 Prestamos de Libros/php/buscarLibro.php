<?php  
// -----------------------------------------------------
// buscarLibro.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['id']))
{
    // Obtenemos los 7 datos
    $id = $_GET['id'];    

    // Preparando el Query para la Consulta
    $query  = " SELECT * FROM libros";
    $query .= " WHERE id_libro = ".$id;
    
    // Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Inicializa el Resultado
    $resultado ="ok";

    // Vaerifica que hay registros
	if ($registros)
	{    
        // Ciclo para procesar cada registro de usario
        if (mysqli_num_rows($registros)>0)
        { 
           // Lee un Registro
           $fila = $registros->fetch_assoc();

           // agrega los datos al resultado
           $resultado  = $resultado .",".$fila['id_autor'].",".$fila['id_editorial'];
           $resultado  = $resultado .",".$fila['titulo'].",".$fila['edicion'];
           $resultado  = $resultado .",".$fila['isbn'].",".$fila['noPaginas'];
           $resultado  = $resultado .",".$fila['annio'];
        }
        else
        {
          $resultado ="No se encontró el Libro con el id indicado";
        }  
	}  
    else
       // Error
       $resultado = $conexion->error;

    // Imprime el Resultado
    echo $resultado;
}
else
{
   echo "Faltaron datos en la consulta";
}
?>