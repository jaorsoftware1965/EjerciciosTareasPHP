<?php  
// -----------------------------------------------------
// cambiarAlumno.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['noControl']) && 
    isset($_GET['carrera'])   &&
    isset($_GET['nombre'])    &&
    isset($_GET['paterno'])   &&
    isset($_GET['materno'])   &&
    isset($_GET['correo'])    &&
    isset($_GET['direccion']) &&
    isset($_GET['telefono'])
   )
{
	// Obtiene los datos
	$noControl  = $_GET['noControl'];
    $carrera    = $_GET['carrera'];
	$nombre     = $_GET['nombre'];
	$paterno    = $_GET['paterno'];
    $materno    = $_GET['materno'];
    $correo     = $_GET['correo'];
    $direccion  = $_GET['direccion'];
    $telefono   = $_GET['telefono'];


	// Prepara el Query para la Modificación
	$query  = " UPDATE alumnos SET";
    $query .= " id_carrera       = $carrera,";
	$query .= " nombre           = '$nombre',";
    $query .= " apellidoPaterno  = '$paterno',";
    $query .= " apellidoMaterno  = '$materno',";
    $query .= " email            = '$correo',";
    $query .= " direccion        = '$direccion',";
	$query .= " telefono         = '$telefono'";
	$query .= " WHERE noControl  =  $noControl";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Vaerifica que hay registros
    if ($registros)
    {    
        // Verifica si afecto
        if (mysqli_affected_rows($conexion)>0)        
           $resultado = "ok";      
        else        
           $resultado = "No hubo cambios que realizar";        
	}  
    else
       // Error
       $resultado = $conexion->error;

    echo $resultado;
}
else
{
   echo "Faltaron datos en la consulta";
}
?>