<?php  
// -----------------------------------------------------
// insertarLibro.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['id'])        && 
    isset($_GET['autor'])     && 
    isset($_GET['editorial']) &&
    isset($_GET['nombre'])    &&
    isset($_GET['edicion'])   &&
    isset($_GET['isbn'])      &&
    isset($_GET['paginas'])   &&
    isset($_GET['año'])
   )
{
	// Obtiene los datos
	$id        = $_GET['id'];
    $autor     = $_GET['autor'];
	$editorial = $_GET['editorial'];
	$nombre    = $_GET['nombre'];
	$edicion   = $_GET['edicion'];
    $isbn      = $_GET['isbn'];
    $paginas   = $_GET['paginas'];
	$año       = $_GET['año'];

	// Prepara el Query para la Inserción
	$query  = " INSERT INTO libros ";
	$query .= " (id_libro, id_autor, id_editorial, titulo, edicion, isbn, noPaginas, annio)";
	$query .= " VALUES ";
	$query .= " ($id, $autor, $editorial,'$nombre','$edicion','$isbn','$paginas','$año')";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Verifica
	if ($registros)
	{   
	    // Variables para el Error
	    echo "ok";
	}   
	else
	{   
	    echo "Error.".mysqli_errno($conexion) . ": " . mysqli_error($conexion) . "\n";
	}
}
else
{
   echo "Faltaron datos en la consulta";
}
?>