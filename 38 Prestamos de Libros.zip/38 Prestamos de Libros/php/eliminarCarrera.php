<?php  
// -----------------------------------------------------
// eliminarCarrera.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['id']))
{
    // Obtenemos los 7 datos
    $id   = $_GET['id'];    

    // Preparando el Query para la Consulta
    $query  = " DELETE FROM carreras";
    $query .= " WHERE id_carrera = ".$id;
    
    
    // Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Inicializa el Resultado
    $resultado ="";

    // Vaerifica que hay registros
	  if ($registros)
	  {    
        // Verifica si afecto
        if (mysqli_affected_rows($conexion)>0)        
           $resultado = "ok";      
        else        
           $resultado = "No se encontró la carrera con el Id indicado";        
	  }  
    else
       // Error
      $resultado = $conexion->error;

    // Imprime el Resultado
    echo $resultado;
}
else
{
   echo "Faltaron datos en la consulta";
}

?>