<?php  
// -----------------------------------------------------
// cambiarEditorial.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

// Verificamos que hayan llegado los datos
if (isset($_GET['id'])    && 
    isset($_GET['nombre'])&&
    isset($_GET['pais'])
   )
{
	// Obtiene los datos
	$id     = $_GET['id'];
	$nombre = $_GET['nombre'];
	$pais   = $_GET['pais'];

	// Prepara el Query para la Modificación
	$query  = " UPDATE editoriales SET";
	$query .= " nombre  = '$nombre',";
	$query .= " pais    = '$pais'";
	$query .= " WHERE id_editorial = $id";

	// Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Vaerifica que hay registros
    if ($registros)
    {    
        // Verifica si afecto
        if (mysqli_affected_rows($conexion)>0)        
           $resultado = "ok";      
        else        
           $resultado = "No hubo cambios que realizar";        
	}  
    else
       // Error
       $resultado = $conexion->error;

    echo $resultado;
}
else
{
   echo "Faltaron datos en la consulta";
}


?>