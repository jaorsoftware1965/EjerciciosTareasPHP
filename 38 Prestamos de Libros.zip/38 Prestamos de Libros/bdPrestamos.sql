-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Versión del servidor:         10.3.16-MariaDB - mariadb.org binary distribution
-- SO del servidor:              Win64
-- HeidiSQL Versión:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Volcando estructura de base de datos para prestamos
CREATE DATABASE IF NOT EXISTS `prestamos` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_spanish_ci */;
USE `prestamos`;

-- Volcando estructura para tabla prestamos.alumnos
CREATE TABLE IF NOT EXISTS `alumnos` (
  `noControl` int(11) NOT NULL,
  `id_carrera` int(11) NOT NULL,
  `nombre` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '',
  `apellidoPaterno` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '',
  `apellidoMaterno` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '',
  `direccion` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '',
  `email` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '',
  `telefono` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`noControl`),
  KEY `FK_Alumnos_carreras` (`id_carrera`),
  CONSTRAINT `FK_Alumnos_carreras` FOREIGN KEY (`id_carrera`) REFERENCES `carreras` (`id_carrera`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci COMMENT='Tabla de Alumnos';

-- Volcando datos para la tabla prestamos.alumnos: ~3 rows (aproximadamente)
/*!40000 ALTER TABLE `alumnos` DISABLE KEYS */;
INSERT INTO `alumnos` (`noControl`, `id_carrera`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `direccion`, `email`, `telefono`) VALUES
	(10, 1, 'Jose', 'MIjares', 'Estevez', 'En el centro', 'admin@correo.com', '1231232'),
	(20, 1, 'Diana', 'Golden', 'Ramirez', 'Conocido', 'conocido', '2342343'),
	(212, 22, 'Helena', 'Troya', 'Cardenas', 'Industrila', 'email', '55443');
/*!40000 ALTER TABLE `alumnos` ENABLE KEYS */;

-- Volcando estructura para tabla prestamos.autores
CREATE TABLE IF NOT EXISTS `autores` (
  `id_autor` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `apellidoPaterno` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `apellidoMaterno` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `nacionalidad` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_autor`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci COMMENT='Autores de los Libros';

-- Volcando datos para la tabla prestamos.autores: ~2 rows (aproximadamente)
/*!40000 ALTER TABLE `autores` DISABLE KEYS */;
INSERT INTO `autores` (`id_autor`, `nombre`, `apellidoPaterno`, `apellidoMaterno`, `nacionalidad`) VALUES
	(1, 'Joe', 'Smith', 'Denver', 'Mexicana'),
	(2, 'Jame', 'Paul', 'McArney', 'Inglesa'),
	(123, 'Jhno', 'Bush', 'Smith', 'Americano');
/*!40000 ALTER TABLE `autores` ENABLE KEYS */;

-- Volcando estructura para tabla prestamos.carreras
CREATE TABLE IF NOT EXISTS `carreras` (
  `id_carrera` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_carrera`)
) ENGINE=InnoDB AUTO_INCREMENT=445 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci COMMENT='Tabla de Carreras ';

-- Volcando datos para la tabla prestamos.carreras: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `carreras` DISABLE KEYS */;
INSERT INTO `carreras` (`id_carrera`, `nombre`) VALUES
	(1, '1-Informatica'),
	(2, '2-Contabilidad'),
	(3, '3-Medicina'),
	(22, '22-Psicologia'),
	(444, '444-Fisica');
/*!40000 ALTER TABLE `carreras` ENABLE KEYS */;

-- Volcando estructura para tabla prestamos.editoriales
CREATE TABLE IF NOT EXISTS `editoriales` (
  `id_editorial` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  `pais` varchar(50) COLLATE latin1_spanish_ci DEFAULT NULL,
  PRIMARY KEY (`id_editorial`)
) ENGINE=InnoDB AUTO_INCREMENT=778 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci COMMENT='Tabla de las Editoriales';

-- Volcando datos para la tabla prestamos.editoriales: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `editoriales` DISABLE KEYS */;
INSERT INTO `editoriales` (`id_editorial`, `nombre`, `pais`) VALUES
	(1, 'Limusa', 'USA'),
	(2, 'Editorial Trillas', 'Mexico'),
	(3, 'Microsoft Press', 'USA'),
	(777, 'Cambbridge 777', 'USA');
/*!40000 ALTER TABLE `editoriales` ENABLE KEYS */;

-- Volcando estructura para tabla prestamos.libros
CREATE TABLE IF NOT EXISTS `libros` (
  `id_libro` int(11) NOT NULL AUTO_INCREMENT,
  `id_autor` int(11) NOT NULL DEFAULT 0,
  `id_editorial` int(11) NOT NULL DEFAULT 0,
  `titulo` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  `edicion` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  `isbn` varchar(50) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  `noPaginas` smallint(6) NOT NULL DEFAULT 0,
  `annio` varchar(4) COLLATE latin1_spanish_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_libro`),
  KEY `FK_Libros_autores` (`id_autor`),
  KEY `FK_Libros_editoriales` (`id_editorial`),
  CONSTRAINT `FK_Libros_autores` FOREIGN KEY (`id_autor`) REFERENCES `autores` (`id_autor`),
  CONSTRAINT `FK_Libros_editoriales` FOREIGN KEY (`id_editorial`) REFERENCES `editoriales` (`id_editorial`)
) ENGINE=InnoDB AUTO_INCREMENT=766 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci COMMENT='Tabla de Libros';

-- Volcando datos para la tabla prestamos.libros: ~4 rows (aproximadamente)
/*!40000 ALTER TABLE `libros` DISABLE KEYS */;
INSERT INTO `libros` (`id_libro`, `id_autor`, `id_editorial`, `titulo`, `edicion`, `isbn`, `noPaginas`, `annio`) VALUES
	(7, 1, 1, 'Python', '1a', 'isbn-234', 222, '2002'),
	(10, 2, 2, 'Microsoft Press', 'afsad', 'asdfa', 0, '2002'),
	(345, 123, 777, 'Lenguaje C', '12a', 'isbn-444', 456, '2003'),
	(765, 123, 777, 'Visual Basic', '2da', 'ISBN-22222', 222, '2002');
/*!40000 ALTER TABLE `libros` ENABLE KEYS */;

-- Volcando estructura para tabla prestamos.prestamos
CREATE TABLE IF NOT EXISTS `prestamos` (
  `id_prestamo` int(11) NOT NULL AUTO_INCREMENT,
  `id_libro` int(11) NOT NULL DEFAULT 0,
  `noControl` int(11) NOT NULL DEFAULT 0,
  `fecha_prestamo` date NOT NULL,
  `fecha_vencimiento` date NOT NULL,
  `multa` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id_prestamo`),
  KEY `FK_prestamos_libros` (`id_libro`),
  KEY `FK_prestamos_alumnos` (`noControl`),
  CONSTRAINT `FK_prestamos_alumnos` FOREIGN KEY (`noControl`) REFERENCES `alumnos` (`noControl`),
  CONSTRAINT `FK_prestamos_libros` FOREIGN KEY (`id_libro`) REFERENCES `libros` (`id_libro`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_spanish_ci;

-- Volcando datos para la tabla prestamos.prestamos: ~5 rows (aproximadamente)
/*!40000 ALTER TABLE `prestamos` DISABLE KEYS */;
INSERT INTO `prestamos` (`id_prestamo`, `id_libro`, `noControl`, `fecha_prestamo`, `fecha_vencimiento`, `multa`) VALUES
	(12, 7, 10, '2021-06-30', '2021-06-30', 0.00),
	(13, 345, 212, '2021-06-30', '2021-06-30', 0.00),
	(14, 345, 212, '2021-06-30', '2021-06-30', 0.00),
	(15, 765, 212, '2021-06-30', '2021-06-30', 0.00),
	(16, 345, 20, '2021-06-30', '2021-06-30', 0.00);
/*!40000 ALTER TABLE `prestamos` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
