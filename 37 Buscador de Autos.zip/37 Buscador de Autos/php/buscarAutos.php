<?php  
// -----------------------------------------------------
// buscarAutos.php
// -----------------------------------------------------

// Incluimos la conexion
require "conexion.php";

//print_r($_GET);
//echo "<br>";

// Verificamos que hayan llegado los datos
if (isset($_GET['marca'])   && 
	  isset($_GET['anio'])    &&
	  isset($_GET['minimo'])  &&
	  isset($_GET['maximo'])  &&
	  isset($_GET['puertas']) &&
	  isset($_GET['transm'])  &&
	  isset($_GET['color'])
   )
{
	  // Mensaje
    //echo "Los Datos llegaron correctamente <br>";

    // Obtenemos los 7 datos
    $marca   = $_GET['marca'];
    $anio    = $_GET['anio'];    
    $minimo  = $_GET['minimo'];
    $maximo  = $_GET['maximo'];
    $puertas = $_GET['puertas'];
    $transm  = $_GET['transm'];
    $color   = $_GET['color'];

    // Preparando el Query para la Consulta
    $query = "SELECT * FROM autos";

    // Inicializamos condicion
    $condicion ="";

    // Verificamos que condiciones agregar
    if (strlen($marca)>0)
    	$condicion = " WHERE marca = '".$marca."'";

    if (strlen($anio)>0)
       if (strlen($condicion)==0)
    	    $condicion = " WHERE anio = ".$anio;
       else	
       	  $condicion .= " AND anio = ".$anio;

    if (strlen($minimo)>0)
       if (strlen($condicion)==0)
    	  $condicion = " WHERE precio >= ".$minimo;
       else	
       	  $condicion .= " AND   precio >= ".$minimo;   	

    if (strlen($maximo)>0)
       if (strlen($condicion)==0)
    	  $condicion = " WHERE precio <= ".$maximo;
       else	
       	  $condicion .= " AND   precio <= ".$maximo;   	
    
    if (strlen($puertas)>0)
       if (strlen($condicion)==0)
    	  $condicion = " WHERE puertas = ".$puertas;
       else	
       	  $condicion .= " AND   puertas >= ".$puertas;   	
    
    if (strlen($transm)>0)
       if (strlen($condicion)==0)
    	  $condicion = " WHERE transmision = '".$trans."'";
       else	
       	  $condicion .= " AND   transmision = '".$transm."'";   	
    
    if (strlen($color)>0)
       if (strlen($condicion)==0)
    	  $condicion = " WHERE color = '".$color."'";
       else	
       	  $condicion .= " AND   color = '".$color."'";   	
    
    // Verifica si hay condicion
    if (strlen($condicion)>0)
    	$query.=" ".$condicion;
    
    // Despliega el Query
    //echo $query."<br>";

    // Ejecuta Query y obtiene Registros
	$registros = $conexion->query($query);

    // Vaerifica que hay registros
	if ($registros)
	{    
	    // Ciclo para procesar cada registro de usario
        while ($fila = $registros->fetch_assoc()) 
        { 

           // Despliega los datos
           echo "<div class='alert alert-success'>";
           		echo $fila['modelo']."-";
           		echo $fila['marca']."-";
           		echo $fila['anio']."-";
           		echo $fila['puertas']."-";
           		echo $fila['transmision']."-";
           		echo $fila['color']."-";
           		echo $fila['precio'];
           echo "</div>";
        }
	}  
	else
		echo "No se encontraron registros con el criterio indicado";
}
else
{
   echo "Faltaron datos en la consulta";
}


?>