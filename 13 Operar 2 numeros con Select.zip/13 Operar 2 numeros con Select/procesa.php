<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: sumar 2 datos con select
// -----------------------------------------------

print_r($_POST);
echo "<br>";


// Verifico primero que los 3 datos existan
if (isset($_POST['nmDato1']) && 
	isset($_POST['nmDato2']) &&
    isset($_POST['operador']))
{
	// Obtengo los datos
	$dato1 = $_POST['nmDato1'];
	$dato2 = $_POST['nmDato2'];
	$op    = $_POST['operador'];
	
	// Verifica que operación realizar
	if ($op =='+')
	{
		// Ejecuta Suma
	    $resultado = $dato1 + $dato2;

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";
	}
	elseif ($op =='-')
	{
	    // Ejecuta Resta
	    $resultado = $dato1 - $dato2;

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";	
	}
	elseif ($op =='*')
	{
	    // Ejecuta Multiplicación
	    $resultado = $dato1 * $dato2;

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";		
	}
	elseif ($op =='/')
	{
		// Ejecuta Multiplicación
	    $resultado = $dato1 / $dato2;

	    // Despliega
	    echo "El resultado de $dato1 $op $dato2 es : $resultado";	
	}
}
else
{	
	echo "No llegaron los datos esperados";
}

echo "<br>Programa terminado";

?>



