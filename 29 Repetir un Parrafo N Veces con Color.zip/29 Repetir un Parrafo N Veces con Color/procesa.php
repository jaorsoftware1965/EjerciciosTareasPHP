<?php

// Función para crear un párrafo con Color
function fnCreaH1ConColor($titulo,$color)
{
	// Crea el H1
    echo "<h1 style ='color:$color'>$titulo</h1>\n";
}
// Función para crear un párrafo con Color
function fnCreaParrafoConColor($parrafo,$color)
{
	// Crea el Párrafo
    echo "<p style ='color:$color'>$parrafo</p>\n";
}


// Función que construye la pagina
function fnCreaPagina($titulo,
	                  $parrafo, 
	                  $color, 
	                  $veces)
{
	// Creamos la página
	echo  "<!DOCTYPE html>\n";
	echo "<html>\n";
	echo "<head>\n";
    echo "<title>$titulo</title>\n";
	echo "</head>\n";
	echo "<body>\n";

    // Crea el H1
    fnCreaH1ConColor($titulo,"BLUE");

	// Ciclo para reptir el parrafo
	for ($i=0; $i <$veces; $i++) 
	{ 
	     fnCreaParrafoConColor($parrafo." [$i]",$color);
	}
	
	// Cierro el Body y el Html
	echo "</body>\n";
	echo "</html>\n";
}


// validamos los datos
if (isset($_POST["parrafo"]) && 
    isset($_POST["color" ]) &&
    isset($_POST["veces"]))
{
	// Obtengo los 3 datos
	$parrafo  = $_POST["parrafo"];
	$color    = $_POST["color"];
	$veces    = $_POST["veces"];

	// Llama a la función
	fnCreaPagina("Repetir un Parrafo $veces Veces",
		         $parrafo, 
		         $color, 
		         $veces);   
}
else
{
	echo "Los Datos no llegaron <br>";
}

?>