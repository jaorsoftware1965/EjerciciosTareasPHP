<?php

function fnProcesaCalifaciones($Materia, $Calificaciones)
{
	// Suma
	$sumaCalificaciones = 0;
    $errores            = 0;
    $noAprobadas        = 0;

    // Analizando
    echo "Materia:$Materia<br>";
    
    // Ciclo para procesar las materias
    foreach ($Calificaciones as $calificacion) 
    {
        // Verifica si es numero antes de sumar
        if (is_numeric($calificacion))
        {
    	   // Lo suma
    	   $sumaCalificaciones+=$calificacion;    

           // Verifica si es reprobada
           if ($calificacion < 60)
           {
              $noAprobadas++;
           }
        }
        else
        {
            // Incrementa los errores            
            $errores++;
        }   
    }

    // Mensaje de errores
    echo "Errores en los datos:$errores<br>";

    echo "Cantidad de Calificaciones:";
    echo count($Calificaciones) - $errores;
    echo "<br>";

    // Despliego la Suma
    echo "Suma de Calificaciones:";
    echo $sumaCalificaciones;
    echo "<br>";

    // Promedio
    $promedio = $sumaCalificaciones / (count($Calificaciones) 
                                    - $errores);

    // Mensaje del Promedio y No Aprobadas
    echo "Promedio de Calificaciones:$promedio<br>";
    echo "Calificaciones no aprobadas:$noAprobadas<br><br>";
}

// Imprime el POST
echo "POST<br>";
print_r($_POST);
echo "<br><br>";

// Verifica que haya llegado
if (isset($_POST["espanol"]) &&
    isset($_POST["matematicas"]) &&
    isset($_POST["sociales"]) &&
    isset($_POST["naturales"]) &&
    isset($_POST["fisica"]))
{	
	// las calificaciones de cada Materia en un Arreglo o Vector
	$calEspañol     = explode(",",$_POST["espanol"]);
	$calMatematicas = explode(",",$_POST["matematicas"]);
	$calSociales    = explode(",",$_POST["sociales"]);
	$calNaturales   = explode(",",$_POST["naturales"]);
	$calFisica      = explode(",",$_POST["fisica"]);

	// Llama a la función con cada arreglo
	fnProcesaCalifaciones("Espanol",$calEspañol);
	fnProcesaCalifaciones("Matematicas",$calMatematicas);
    fnProcesaCalifaciones("C Sociales",$calSociales);
    fnProcesaCalifaciones("C Naturales",$calNaturales);
    fnProcesaCalifaciones("E Fisica",$calFisica);
}
else
{
	echo "No llegaron los datos<br>";
}

// Mensaje
echo "Programa Terminado<br>";

?>