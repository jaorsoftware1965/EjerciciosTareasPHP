<?php  

// Que he aprendido del LADO del SERVIDOR o sea PHP
// 1.- Que existe el arreglo POST que contiene los datos enviados 
// 2.- Que debes verificar que el dato que esperas recibir
//     Exista en el Arreglo, usando la función isset
// 3.- Que debo de pasar el dato del Arreglo a una variable

// Imprimo el vector del $_POST
print_r($_POST); // 1
echo "</br></br>";

// Verifico que llegue lo que espero
if (isset($_POST["dato"]))// 2
{
	// Tomo el dato del arreglo $_POST
	$datoRecibido = $_POST["dato"]; // 3

	// Despliego la variable
	echo "El Dato recibido es:</br>";
	echo $datoRecibido;
	echo "</br>";

	echo "La longitud del Dato Recibido es:";
	echo strlen($datoRecibido);
	echo "</br>";
	// ----------------------------------------------
}
else
{
	echo "No llego el dato que esperaba</br>";
	echo "</br>";
}

// Fin del Programa
echo "Programa finalizado ...";


?>

<!-- EJERCICIO.
1- Crear un archivo html, que tenga un:
a) Encabezado que diga "Ejercicio de Saludo Personal"
b) Parrafo    que diga "Capture un Nombre"
c) Crear un Formulario con el nombre del archivo a ejecutar y el metodo post
d) Crear una entrada de datos
e) Crear un boton de Enviar

2.- Crear el archivo PHP que se indicó en el formulario en el atributo action
a) Imprimir el Arreglo POST
b) Verificar que el dato que esperas llego
c) Pasar el dato a una variable
d) Si el dato llego, que es un nombre, desplegar un saludo así:
   "Hola ->".variable  -->
