<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Desplegar el dato desde el Formulario
// -----------------------------------------------

// Desplegando los datos de $_POST
echo "POST->";
$_POST["nombre"]="jaor";
print_r($_POST); // Arreglo Global donde se almacena lo que se recibe
echo "<br>";
echo "<br>";

// Verifico primero que el dato exista
if (isset($_POST['nameDato']))
{
	// Obtengo el Dato
    $dato = $_POST['nameDato'];

    // Imprimo el Dato
	print "El Dato recibido es:<br>";	
    print $dato."<br>";
}
else
{
	print "El Dato esperado no se pudo obtener<br>";
	print "Verifica que el name del dato sea EXACTAMENTE: 'nameDato'";
}

// Finaliza
echo "Programa Finalizado ..."

?>



