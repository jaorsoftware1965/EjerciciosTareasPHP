<?php

// Función para Operar
function fnOperar($x,$y,$operador)
{
  // Variable para el Resultado
  $resultado = 0;
  
  switch ($operador) 
  {
    case '+':
      $resultado = $x + $y;
      break;
    
    case '-':
      $resultado = $x - $y;
      break;

    case '*':
      $resultado = $x * $y;
      break;  

    case '/':
      $resultado = $x / $y;
      break;  

    case '%':
      $resultado = $x % $y;
      break;    

    case '.':
      $resultado = $x . $y;
      break;  

    case '<':
      $resultado = $y . $x;
      break;    
  
    default:
      $resultado = "?";
      break;

  } // Acà termina el switch

  // retorna el resultado
  return $resultado;
}


// Imprime el POST
echo "POST<br>";
print_r($_POST);
echo "<br><br>";

// Verifica que haya llegado
if (isset($_POST["datos"]))
{	
	  // Obtiene las Operaciones
	  $datos = explode(";",$_POST["datos"]);
    
    // Contadores
    $errores = 0; 
    $errorEnOperando = 0;   

    // Ciclo
    foreach ($datos as $valor) 
    {
        // Obtiene las operaciones
        $operacion = explode(" ", $valor);
    
        // Verifica que sean 3 datos
        if (count($operacion) == 3)
        {
 
           // Verifica si son numericos los operandos
           if (is_numeric($operacion[0]) && 
               is_numeric($operacion[2]))
           {    

               // Obtiene los operandos
               $op1 = $operacion[0];
               $op2 = $operacion[2];

               // Obtiene el Operador
               $op  = $operacion[1];

               //Llama a la función
               echo "$op1 $op $op2 = ";

               // Verifico si es división y es 0
               if ($op=="/" && $op2==0)
               {
                  // Error en Operando
                  $errorEnOperando++;
                  echo "?";
               }
               else
               { 
                  // Llamar a la Función
                  echo fnOperar($op1,$op2,$op);
               }
               echo "<br>";
                
           }
           else
           {
               // Incrementa el Error en el Operando
               $errorEnOperando++;
           }
           
        }
        else
        {
            // Incrementa los errores
            $errores++;
        }
    }
    echo "<br>";

    // MEnsajes
    echo "Operaciones Recibidas: ".count($datos)."<br>";
    echo "Errores : $errores<br>";
    echo "Errores en Operandos : $errorEnOperando<br>";
    
}
else
{
	echo "No llegaron los datos<br>";
}

// Mensaje
echo "<br>Programa Terminado<br>";

?>