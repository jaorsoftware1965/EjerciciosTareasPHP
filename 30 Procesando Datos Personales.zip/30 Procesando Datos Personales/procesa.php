<?php

echo "El Arreglo POST:<br>";
print_r($_POST);
echo "<br><br>";

// validamos los datos
if (isset($_POST["datos"]))
{
	// Declarar variables de Conteo
	$hombres = 0;
	$mujeres = 0;
	$mayores = 0;
	$menores = 0;
	$errores = 0;

	// Obtengo los datos
	$datos  = explode(";", $_POST["datos"]);
	echo "El Arreglo datos:<br>";
	print_r($datos);
	echo "<br><br>";

	// Ciclo para procesar la información de las Personas
	foreach ($datos as $dato) 
	{
		// Convierto a arreglo el dato
		$persona = explode(",", $dato);

		// Verifica que son 4 datos
		if (count($persona)==4)
		{
			// Verifica si es hombre
			if ($persona[2]=="H")
			{
				// Incrementa el Contador de Hombres
                $hombres++;
			}
			else
			{
				// Incrementa el Contador de Hombres
                $mujeres++;
			}

			// Verifica si es mayor de edad
			if ($persona[1]>=18)
			{
				// Incrementa el Contador de Mayores
                $mayores++;
			}
			else
			{
				// Incrementa el Contador de menores
                $menores++;
			}

			// Desplegando información de la persona
		    echo "Nombre: $persona[0]<br>";
		    echo "Edad  : $persona[1]<br>";
		    echo "Genero: $persona[2]<br>";
		    echo "Ocupación: $persona[3]<br><br>";		
		}
		else
		{
			// Aumenta los errores
			$errores++;
		}
	}

	// Mensaje
	echo "Numero de Personas procesadas:".count($datos)."<br>";
	echo "Numero de Hombres:$hombres<br>";
	echo "Numero de Mujeres:$mujeres<br>";
	echo "Numero de Mayores de Edad:$mayores<br>";
	echo "Numero de Menores de Edad:$menores<br>";
	echo "Numero de Errores:$errores<br>";

}
else
{
	echo "Los Datos no llegaron <br>";
}

?>