<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Desplegar un tabla
// -----------------------------------------------

// Desplegamos el Arreglo
print_r($_POST);
echo "<br><br>";


// Verifico primero que el dato exista
if (isset($_POST['tabla']) && 
	isset($_POST['inicial']) &&
    isset($_POST['final']) &&
    isset($_POST['incremento']))
{
	// Obtengo los datos
	$tabla      = $_POST['tabla'];
	$inicial    = $_POST['inicial'];
	$final      = $_POST['final'];
	$incremento = $_POST['incremento'];
	
	// Desplegamos Titulo de la Tabla
	echo "Tabla de Multiplicar del $tabla<br>";

    // verifico si es ascendente o descente
    if ($inicial < $final)
    {
    	// Desplegando la tabla
		for ($x=$inicial; $x <= $final; $x+=$incremento)
		{
			// Desplegamos la operación
			echo "$tabla x $x = ". $tabla * $x ."<br>";
		}
    }
    else
    {
        // Desplegando la tabla
		for ($x=$inicial; $x >= $final; $x-=$incremento)
		{
			// Desplegamos la operación
			echo "$tabla x $x = ". $tabla * $x ."<br>";
		}
    }
	
	echo "<br>";	
}
else
{	
	echo "No llegaron los datos esperados<br>";
}

echo "Programa Terminado ...";
?>



