<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Obtener valores sin rpetir
// -----------------------------------------------

// Imprimimos el POST
print_r($_POST);
echo "<br><br>";

// Verificamos llegada
if (isset($_POST["datos"]))
{
	// Paso los datos a un vector o aun arreglo
	$datos = explode(",", $_POST["datos"]);    

    // Variable que va a contar las repeticiones
    $sinRepetir = [];

    // Indice
    $indice = 0;

	// Ciclo para recorrer los datos
	foreach ($datos as $valor) 
	{
		// Verifica que no está en el vector
		if (!in_array($valor, $sinRepetir))
		{
			// Lo agrega
			$sinRepetir[$indice++] = $valor;
		}
	}
	
	// Mensaje Resultados
	echo "Los Datos sin repetir son:<br>";
	foreach ($sinRepetir as $valor) 
	{
		echo "[$valor]";
	}
	echo "<br>";
}
else
{
	// Mensaje
	echo "Los datos no llegaron<br>";
}

// Mensaje Final
echo "Programa Terminado"

?>



