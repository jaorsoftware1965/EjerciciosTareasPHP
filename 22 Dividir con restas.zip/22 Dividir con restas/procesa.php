<?php
// ----------------------------------------------------------
// Procesa.php
// Objetivo: Divivir 1 numero entre otro con restas sucesivas
// ----------------------------------------------------------

// Desplegamos el Post
print_r($_POST);
echo "<br><br>";

// validamos los datoa
if (isset($_POST["dato1"]) && isset($_POST['dato2']))
{
	// Obtengo los 2 datos
	$dividendo = $_POST["dato1"];
	$divisor   = $_POST["dato2"];

    // Varieble para el cociente
    $cociente = 0;

	// Ciclo 
	while ($dividendo >= $divisor)
	{
		// Incrementamos el Cociente
		$cociente++;

		// Restamos
		$dividendo -= $divisor;

		echo "Dividendo:$dividendo<br>";
		echo "Cociente:$cociente<br>";		
	}
	
	// Desplegamos el Cociente
	echo "<br>";
	echo "El Cociente es:$cociente<br>";
	echo "El Residuo  es:$dividendo<br>";
    
}
else
{
	echo "Los Datos no llegaron <br>";
}

// Fin del Programa
echo "Programa terminado ...";


?>



