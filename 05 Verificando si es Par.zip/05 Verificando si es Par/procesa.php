<?php
// -----------------------------------------------
// Procesa.php
// Objetivo: Verificar si un dato es numérico
// -----------------------------------------------

print_r($_POST);
echo "<br><br>";


// Verifico primero que el dato exista
if (isset($_POST['nmDato']))
{
    // Paso el Dato a una variable
    $dato = $_POST['nmDato'];

	// Lo despliego
	echo "El Dato recibido es:<br>";	
    echo $dato,"</br></br>";    

    // Verifica si es numero par por el residuo
    if ($dato % 2 == 0)
    {
    	echo "El Dato Si es un numero par verificado por residuo</br></br>";
    }
    else
    {
    	echo "El dato No es un numero par, falla verificando por residuo</br></br>";
    }        

    // Verificando por substring
    // Obtenemos el ultimo caracter
    $ultimoDigito = substr($dato,            //<----- de donde
                           strlen($dato)-1, //<----- que posicion
                           1);              //<----- cuantos
    echo "El Ultimo Digito es:$ultimoDigito</br></br>";

    switch ($ultimoDigito) 
    {
        case '2':
        case '4':
        case '6':
        case '8':
        case '10':
             echo "El Dato Si es un numero par verificado por último dígito</br>";   
             break;                 
        default: // Aca entra cuando es:1,3,5,7,9
             echo "El Dato No es un numero par, falla verificando último dígito<br>";
            break;
    }
}
else
{
	echo "El Dato esperado no se pudo obtener<br>";
}

echo "Programa Finalizado"

?>










